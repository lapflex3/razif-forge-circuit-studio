import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="min-h-screen bg-[#070708] flex flex-col items-center justify-center p-4 text-center font-mono">
      <h2 className="text-2xl font-bold text-[#00FF00] mb-2 uppercase">404 - Page Not Found</h2>
      <p className="text-xs text-[#888] mb-4">The requested CircuitForge resource does not exist.</p>
      <Link
        href="/"
        className="px-4 py-2 bg-[#00FF00] text-[#0A0A0B] font-bold text-xs uppercase rounded-sm"
      >
        Return to Workspace
      </Link>
    </div>
  );
}
