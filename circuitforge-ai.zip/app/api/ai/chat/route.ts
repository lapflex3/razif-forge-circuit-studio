import { GoogleGenAI, Type } from '@google/genai';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { prompt, projectContext, customApiKey, model, activeSkillRules } = body;

    const apiKey = customApiKey || process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return NextResponse.json(
        { error: 'No AI API key found. Please input custom AI API Key in Settings or configure GEMINI_API_KEY in Secrets.' },
        { status: 500 }
      );
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const skillRulesText = Array.isArray(activeSkillRules) && activeSkillRules.length > 0
      ? `\nActive Applied Project Skill Rules:\n${activeSkillRules.map((rule, i) => `${i + 1}. ${rule}`).join('\n')}\n`
      : '';

    const systemInstruction = `You are CircuitForge Engineering AI, a senior Electronic Design Automation (EDA) & Embedded Systems Lead Engineer.
You assist with electronics design, hardware architecture, circuit analysis, component selection, pin mapping, power tree analysis, PCB planning, engineering calculations, LCSC parts procurement, and ERC review.

Rules:
1. Reason systematically and strictly prioritize electrical safety and engineering correctness.
2. Check voltage rail compatibility, current requirements, IC pin conflicts, I2C pull-ups, and decoupling capacitors.
3. Distinguish verified facts from estimates. Never invent datasheet specs, prices, or false certifications.
4. When suggesting components, prioritize verified LCSC part numbers (e.g. C2913202, C6186, C16581) for EasyEDA/SMRT assembly compatibility.
5. When a user asks to add or modify a circuit block/component, provide an engineering breakdown and structured operation.
6. You can propose a structured JSON change operation in your response inside a \`\`\`json\`\`\` block with the format:
{
  "proposal": {
    "action": "add_component" | "add_block" | "connect_blocks" | "add_net" | "add_power_rail" | "fix_warning" | "modify_circuit",
    "title": "Short title of change",
    "description": "Clear explanation of engineering change",
    "payload": { ... details ... }
  }
}
${skillRulesText}
Current Project Context:
${JSON.stringify(projectContext, null, 2)}
`;

    const modelName = model || 'gemini-3.6-flash';

    const response = await ai.models.generateContent({
      model: modelName,
      contents: prompt,
      config: {
        systemInstruction,
        temperature: 0.2,
      },
    });

    const textOutput = response.text || 'No output generated.';

    // Check if JSON proposal block is present
    let proposal = undefined;
    const jsonMatch = textOutput.match(/```json\s*([\s\S]*?)\s*```/);
    if (jsonMatch && jsonMatch[1]) {
      try {
        const parsed = JSON.parse(jsonMatch[1]);
        if (parsed.proposal) {
          proposal = parsed.proposal;
        }
      } catch (e) {
        // Silently ignore malformed json in free text
      }
    }

    // Default suggested actions
    const suggestedActions = [
      'Analyze power tree efficiency',
      'Run AI Design Review',
      'Generate BOM list',
      'Export KiCad schematic files'
    ];

    return NextResponse.json({
      text: textOutput,
      proposal,
      suggestedActions,
    });
  } catch (err: any) {
    console.error('CircuitForge AI API Error:', err);
    return NextResponse.json(
      { error: err.message || 'Error processing AI engineering request' },
      { status: 500 }
    );
  }
}
