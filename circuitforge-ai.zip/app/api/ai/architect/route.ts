import { GoogleGenAI, Type } from '@google/genai';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return NextResponse.json(
        { error: 'GEMINI_API_KEY is missing. Please set it in Secrets.' },
        { status: 500 }
      );
    }

    const { projectName, deviceDescription, powerSource, mainController, interfaces } = await req.json();

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const prompt = `Generate an engineering architecture for an electronic device project:
Name: ${projectName}
Description: ${deviceDescription}
Power Source: ${powerSource}
Main MCU Controller: ${mainController}
Interfaces: ${interfaces.join(', ')}

Return a structured EDA project architecture.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
      config: {
        systemInstruction: `You are CircuitForge AI. Create a realistic block diagram, power rails, component list, and potential engineering warnings for the described electronic hardware device.`,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            blocks: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  name: { type: Type.STRING },
                  type: { type: Type.STRING },
                  voltageRail: { type: Type.STRING },
                  currentDraw: { type: Type.STRING },
                  description: { type: Type.STRING },
                },
                required: ['id', 'name', 'type', 'description'],
              },
            },
            components: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  ref: { type: Type.STRING },
                  name: { type: Type.STRING },
                  manufacturer: { type: Type.STRING },
                  partNumber: { type: Type.STRING },
                  category: { type: Type.STRING },
                  package: { type: Type.STRING },
                  value: { type: Type.STRING },
                  description: { type: Type.STRING },
                },
                required: ['ref', 'name', 'category', 'package', 'description'],
              },
            },
            powerRails: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  voltage: { type: Type.NUMBER },
                  estimatedCurrent: { type: Type.NUMBER },
                  powerSource: { type: Type.STRING },
                  notes: { type: Type.STRING },
                },
                required: ['name', 'voltage', 'estimatedCurrent', 'powerSource'],
              },
            },
            warnings: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  severity: { type: Type.STRING },
                  category: { type: Type.STRING },
                  message: { type: Type.STRING },
                  recommendation: { type: Type.STRING },
                },
                required: ['title', 'severity', 'message', 'recommendation'],
              },
            },
          },
          required: ['blocks', 'components', 'powerRails', 'warnings'],
        },
      },
    });

    const jsonText = response.text || '{}';
    const parsed = JSON.parse(jsonText);

    return NextResponse.json(parsed);
  } catch (err: any) {
    console.error('CircuitForge AI Architect API Error:', err);
    return NextResponse.json(
      { error: err.message || 'Error generating AI project architecture' },
      { status: 500 }
    );
  }
}
