'use client';

import React, { useState } from 'react';
import { ProjectData, Language, AISettings, EDASettings } from '@/lib/types/eda';
import { DEMO_PROJECT_ESP32_LORA } from '@/lib/sampleData';
import { runERC } from '@/lib/eda/ercEngine';
import { TopBar } from '@/components/layout/TopBar';
import { LeftSidebar, ViewType } from '@/components/layout/LeftSidebar';
import { RightSidebar } from '@/components/layout/RightSidebar';
import { WizardModal } from '@/components/modals/WizardModal';
import { SettingsModal } from '@/components/modals/SettingsModal';

import { ProjectsView } from '@/components/views/ProjectsView';
import { OverviewView } from '@/components/views/OverviewView';
import { BlocksView } from '@/components/views/BlocksView';
import { ComponentsView } from '@/components/views/ComponentsView';
import { SchematicView } from '@/components/views/SchematicView';
import { NetlistView } from '@/components/views/NetlistView';
import { PowerView } from '@/components/views/PowerView';
import { CalculatorsView } from '@/components/views/CalculatorsView';
import { BOMView } from '@/components/views/BOMView';
import { SimulationView } from '@/components/views/SimulationView';
import { DocumentsView } from '@/components/views/DocumentsView';
import { AIReviewView } from '@/components/views/AIReviewView';
import { PCBView } from '@/components/views/PCBView';
import { SkillsView } from '@/components/views/SkillsView';

export default function CircuitForgeApp() {
  const [project, setProject] = useState<ProjectData>(DEMO_PROJECT_ESP32_LORA);
  const [history, setHistory] = useState<ProjectData[]>([DEMO_PROJECT_ESP32_LORA]);
  const [historyIndex, setHistoryIndex] = useState(0);

  const [activeView, setActiveView] = useState<ViewType>('blocks');
  const [language, setLanguage] = useState<Language>('en');

  const [aiSettings, setAiSettings] = useState<AISettings>({
    provider: 'gemini',
    model: 'gemini-3.6-flash',
    temperature: 0.2,
    localEndpoint: 'http://localhost:11434',
  });

  const [edaSettings, setEdaSettings] = useState<EDASettings>({
    defaultUnits: 'mm',
    gridSize: 20,
    snapToGrid: true,
    kicadPath: '/usr/bin/kicad-cli',
  });

  const [isWizardOpen, setIsWizardOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  // Update project with undo history support
  const handleUpdateProject = (newProj: ProjectData) => {
    const updatedHistory = history.slice(0, historyIndex + 1);
    updatedHistory.push(newProj);
    setHistory(updatedHistory);
    setHistoryIndex(updatedHistory.length - 1);
    setProject(newProj);
  };

  const handleUndo = () => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1);
      setProject(history[historyIndex - 1]);
    }
  };

  const handleRedo = () => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(historyIndex + 1);
      setProject(history[historyIndex + 1]);
    }
  };

  const handleRunERC = () => {
    const warnings = runERC(project);
    handleUpdateProject({ ...project, warnings });
    setActiveView('aiReview');
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-[#0A0A0B] text-[#D1D1D1] overflow-hidden font-sans">
      {/* Top Header */}
      <TopBar
        project={project}
        onUpdateProject={handleUpdateProject}
        canUndo={historyIndex > 0}
        canRedo={historyIndex < history.length - 1}
        onUndo={handleUndo}
        onRedo={handleRedo}
        language={language}
        onSelectLanguage={setLanguage}
        aiSettings={aiSettings}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onRunERC={handleRunERC}
        onOpenAIReview={() => setActiveView('aiReview')}
        activeView={activeView}
      />

      {/* Main Container */}
      <div className="flex flex-1 overflow-hidden relative">
        {/* Left Sidebar */}
        <LeftSidebar
          activeView={activeView}
          onSelectView={(v) => {
            if (v === 'settings') {
              setIsSettingsOpen(true);
            } else {
              setActiveView(v);
            }
          }}
          language={language}
          onNewProjectClick={() => setIsWizardOpen(true)}
          warningCount={project.warnings.length}
        />

        {/* View Content Area */}
        <main className="flex-1 overflow-y-auto bg-[#0A0A0B] flex flex-col relative">
          {activeView === 'projects' && (
            <ProjectsView
              currentProject={project}
              onSelectProject={(p) => {
                handleUpdateProject(p);
                setActiveView('blocks');
              }}
              onOpenWizard={() => setIsWizardOpen(true)}
            />
          )}

          {activeView === 'overview' && (
            <OverviewView
              project={project}
              onNavigate={setActiveView}
              onRunERC={handleRunERC}
            />
          )}

          {activeView === 'blocks' && (
            <BlocksView
              project={project}
              onUpdateProject={handleUpdateProject}
            />
          )}

          {activeView === 'components' && (
            <ComponentsView
              project={project}
              onUpdateProject={handleUpdateProject}
            />
          )}

          {activeView === 'schematic' && (
            <SchematicView
              project={project}
              onUpdateProject={handleUpdateProject}
            />
          )}

          {activeView === 'netlist' && (
            <NetlistView
              project={project}
              onUpdateProject={handleUpdateProject}
            />
          )}

          {activeView === 'power' && (
            <PowerView
              project={project}
              onUpdateProject={handleUpdateProject}
            />
          )}

          {activeView === 'calculators' && (
            <CalculatorsView
              project={project}
              onUpdateProject={handleUpdateProject}
            />
          )}

          {activeView === 'bom' && (
            <BOMView project={project} />
          )}

          {activeView === 'simulation' && (
            <SimulationView project={project} />
          )}

          {activeView === 'documents' && (
            <DocumentsView
              project={project}
              onUpdateProject={handleUpdateProject}
            />
          )}

          {activeView === 'aiReview' && (
            <AIReviewView
              project={project}
              onUpdateProject={handleUpdateProject}
              onRunERC={handleRunERC}
            />
          )}

          {activeView === 'pcb' && (
            <PCBView project={project} />
          )}

          {activeView === 'skills' && (
            <SkillsView
              project={project}
              onUpdateProject={handleUpdateProject}
            />
          )}
        </main>


        {/* Right AI Sidebar */}
        <RightSidebar
          project={project}
          onUpdateProject={handleUpdateProject}
          language={language}
          aiSettings={aiSettings}
        />
      </div>

      {/* Modals */}
      <WizardModal
        isOpen={isWizardOpen}
        onClose={() => setIsWizardOpen(false)}
        onCreateProject={(newProj) => {
          handleUpdateProject(newProj);
          setActiveView('blocks');
        }}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        aiSettings={aiSettings}
        onUpdateAISettings={setAiSettings}
        edaSettings={edaSettings}
        onUpdateEDASettings={setEdaSettings}
        language={language}
        onSelectLanguage={setLanguage}
      />
    </div>
  );
}
