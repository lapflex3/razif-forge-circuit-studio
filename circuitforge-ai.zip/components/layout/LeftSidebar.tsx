'use client';

import React from 'react';
import { 
  FolderKanban, 
  LayoutDashboard, 
  Boxes, 
  Cpu, 
  CircuitBoard, 
  Network, 
  Layers, 
  Zap, 
  Calculator, 
  Table, 
  Activity, 
  FileText, 
  ShieldCheck, 
  Settings,
  PlusCircle,
  BrainCircuit
} from 'lucide-react';
import { Language } from '@/lib/types/eda';
import { TRANSLATIONS } from '@/lib/i18n';

export type ViewType = 
  | 'projects'
  | 'overview'
  | 'blocks'
  | 'components'
  | 'schematic'
  | 'netlist'
  | 'pcb'
  | 'power'
  | 'calculators'
  | 'bom'
  | 'simulation'
  | 'documents'
  | 'aiReview'
  | 'skills'
  | 'settings';

interface LeftSidebarProps {
  activeView: ViewType;
  onSelectView: (view: ViewType) => void;
  language: Language;
  onNewProjectClick: () => void;
  warningCount: number;
}

export function LeftSidebar({
  activeView,
  onSelectView,
  language,
  onNewProjectClick,
  warningCount,
}: LeftSidebarProps) {
  const t = TRANSLATIONS[language];

  const navItems: { id: ViewType; label: string; icon: React.ReactNode; badge?: number }[] = [
    { id: 'projects', label: t.projects, icon: <FolderKanban className="w-4 h-4" /> },
    { id: 'overview', label: t.overview, icon: <LayoutDashboard className="w-4 h-4" /> },
    { id: 'blocks', label: t.blocks, icon: <Boxes className="w-4 h-4" /> },
    { id: 'components', label: t.components, icon: <Cpu className="w-4 h-4" /> },
    { id: 'schematic', label: t.schematic, icon: <CircuitBoard className="w-4 h-4" /> },
    { id: 'netlist', label: t.netlist, icon: <Network className="w-4 h-4" /> },
    { id: 'pcb', label: t.pcb, icon: <Layers className="w-4 h-4" /> },
    { id: 'power', label: t.power, icon: <Zap className="w-4 h-4" /> },
    { id: 'calculators', label: t.calculators, icon: <Calculator className="w-4 h-4" /> },
    { id: 'bom', label: t.bom, icon: <Table className="w-4 h-4" /> },
    { id: 'simulation', label: t.simulation, icon: <Activity className="w-4 h-4" /> },
    { id: 'documents', label: t.documents, icon: <FileText className="w-4 h-4" /> },
    { id: 'aiReview', label: t.aiReview, icon: <ShieldCheck className="w-4 h-4" />, badge: warningCount },
    { id: 'skills', label: 'AI ML Skills', icon: <BrainCircuit className="w-4 h-4 text-[#00FF00]" /> },
  ];

  return (
    <aside className="w-56 bg-[#0F0F10] border-r border-[#222] flex flex-col justify-between shrink-0 select-none">
      <div className="p-2 space-y-1 overflow-y-auto">
        <button
          onClick={onNewProjectClick}
          className="w-full flex items-center justify-center space-x-2 bg-[#00FF00] hover:bg-[#00DD00] text-[#0A0A0B] font-bold px-3 py-2 rounded-sm text-xs transition-colors shadow-[0_0_10px_rgba(0,255,0,0.15)] mb-2 uppercase font-mono tracking-wide"
        >
          <PlusCircle className="w-4 h-4" />
          <span>{t.newProject}</span>
        </button>

        <div className="text-[10px] font-mono uppercase text-[#555] px-3 pt-2 pb-1 font-bold tracking-widest">
          EDA Workspace
        </div>

        {navItems.map((item) => {
          const isActive = activeView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectView(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-sm text-xs font-mono transition-all ${
                isActive
                  ? 'bg-[#1A1A1B] text-[#00FF00] border border-[#00FF00]/40 shadow-md font-bold'
                  : 'text-[#888] hover:bg-[#1A1A1B] hover:text-white border border-transparent'
              }`}
            >
              <div className="flex items-center space-x-2.5">
                <span className={isActive ? 'text-[#00FF00]' : 'text-[#666]'}>
                  {item.icon}
                </span>
                <span>{item.label}</span>
              </div>

              {item.badge !== undefined && item.badge > 0 && (
                <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-sm bg-[#1F1713] border border-[#F27D26]/60 text-[#F27D26] font-bold">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      <div className="p-2 border-t border-[#222] bg-[#0A0A0B]">
        <button
          onClick={() => onSelectView('settings')}
          className={`w-full flex items-center space-x-2.5 px-3 py-2 rounded-sm text-xs font-mono transition-colors ${
            activeView === 'settings'
              ? 'bg-[#1A1A1B] text-[#00FF00] border border-[#333]'
              : 'text-[#777] hover:bg-[#1A1A1B] hover:text-[#CCC]'
          }`}
        >
          <Settings className="w-4 h-4 text-[#666]" />
          <span>{t.settings}</span>
        </button>
      </div>
    </aside>
  );
}
