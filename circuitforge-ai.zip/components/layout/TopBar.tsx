'use client';

import React, { useState } from 'react';
import { 
  Cpu, 
  Save, 
  Undo2, 
  Redo2, 
  Download, 
  Upload, 
  ShieldAlert, 
  Bot, 
  Settings, 
  Globe, 
  Check, 
  Sparkles,
  FileCode2
} from 'lucide-react';
import { ProjectData, Language, AISettings } from '@/lib/types/eda';
import { TRANSLATIONS } from '@/lib/i18n';
import { exportToKiCad } from '@/lib/eda/kicadExporter';

interface TopBarProps {
  project: ProjectData;
  onUpdateProject: (p: ProjectData) => void;
  canUndo: boolean;
  canRedo: boolean;
  onUndo: () => void;
  onRedo: () => void;
  language: Language;
  onSelectLanguage: (lang: Language) => void;
  aiSettings: AISettings;
  onOpenSettings: () => void;
  onRunERC: () => void;
  onOpenAIReview: () => void;
  activeView: string;
}

export function TopBar({
  project,
  onUpdateProject,
  canUndo,
  canRedo,
  onUndo,
  onRedo,
  language,
  onSelectLanguage,
  aiSettings,
  onOpenSettings,
  onRunERC,
  onOpenAIReview,
  activeView,
}: TopBarProps) {
  const [isEditingName, setIsEditingName] = useState(false);
  const [projectName, setProjectName] = useState(project.name);
  const [showSavedToast, setShowSavedToast] = useState(false);
  const [showExportMenu, setShowExportMenu] = useState(false);

  const t = TRANSLATIONS[language];

  const handleSaveName = () => {
    setIsEditingName(false);
    if (projectName.trim()) {
      onUpdateProject({ ...project, name: projectName.trim(), updatedAt: new Date().toISOString() });
    }
  };

  const handleManualSave = () => {
    onUpdateProject({ ...project, updatedAt: new Date().toISOString() });
    setShowSavedToast(true);
    setTimeout(() => setShowSavedToast(false), 2000);
  };

  const handleExportJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(project, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `${project.name.toLowerCase().replace(/[^a-z0-9]/g, '_')}.cforge.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    setShowExportMenu(false);
  };

  const handleExportKiCad = () => {
    const result = exportToKiCad(project);
    const blob = new Blob([result.schematicContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${result.projectName}.kicad_sch`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    setShowExportMenu(false);
  };

  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const imported = JSON.parse(event.target?.result as string);
        if (imported.name && imported.blocks) {
          onUpdateProject(imported);
        } else {
          alert('Invalid .cforge.json project format.');
        }
      } catch (err) {
        alert('Error parsing JSON project file.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <header className="h-12 bg-[#111112] border-b border-[#222] text-slate-100 flex items-center justify-between px-4 sticky top-0 z-40 shrink-0">
      {/* Left branding & project name */}
      <div className="flex items-center space-x-3">
        {/* Geometric Balance Logo Badge */}
        <div className="flex items-center space-x-2">
          <div className="w-6 h-6 bg-[#00FF00] flex items-center justify-center rounded-sm shadow-[0_0_8px_rgba(0,255,0,0.3)]">
            <div className="w-3.5 h-3.5 border-2 border-[#0A0A0B] rotate-45" />
          </div>
          <span className="font-bold text-white tracking-tighter text-base font-sans">
            CIRCUIT<span className="text-[#00FF00]">FORGE</span> AI
          </span>
          <span className="text-[9px] font-mono font-bold tracking-wider px-1.5 py-0.5 bg-[#1F1713] text-[#F27D26] border border-[#F27D26]/40 rounded-sm uppercase ml-1">
            RazifSoftwares
          </span>
        </div>

        <div className="h-4 w-[1px] bg-[#333]" />

        {/* Project Tag Badge */}
        <div className="flex items-center space-x-2 bg-[#1A1A1B] px-2.5 py-1 border border-[#333] rounded-sm text-xs font-mono">
          <span className="text-[#777] uppercase font-bold text-[10px]">PROJECT:</span>
          {isEditingName ? (
            <input
              type="text"
              value={projectName}
              onChange={(e) => setProjectName(e.target.value)}
              onBlur={handleSaveName}
              onKeyDown={(e) => e.key === 'Enter' && handleSaveName()}
              className="bg-[#0A0A0B] border border-[#00FF00] rounded px-1.5 py-0.5 text-xs text-[#00FF00] font-bold focus:outline-none"
              autoFocus
            />
          ) : (
            <button
              onClick={() => setIsEditingName(true)}
              className="text-xs font-bold text-[#00FF00] hover:underline transition-all flex items-center space-x-1"
              title="Click to rename project"
            >
              <span>{project.name.toUpperCase().replace(/\s+/g, '_')}</span>
            </button>
          )}
        </div>

        <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-sm bg-[#1A1A1B] text-[#888] border border-[#333]">
          {activeView}
        </span>
      </div>

      {/* Center Action Toolbar */}
      <div className="flex items-center space-x-1.5 bg-[#0A0A0B] p-1 rounded-sm border border-[#222]">
        <button
          onClick={handleManualSave}
          className="flex items-center space-x-1 px-2 py-1 rounded-sm text-xs font-mono uppercase bg-[#222] hover:bg-[#333] border border-[#444] text-[#D1D1D1] transition-colors"
          title={t.save}
        >
          {showSavedToast ? <Check className="w-3.5 h-3.5 text-[#00FF00]" /> : <Save className="w-3.5 h-3.5 text-[#888]" />}
          <span>{showSavedToast ? 'Saved' : t.save}</span>
        </button>

        <div className="h-4 w-[1px] bg-[#333]" />

        <button
          onClick={onUndo}
          disabled={!canUndo}
          className={`px-2 py-1 rounded-sm text-xs font-mono uppercase border transition-colors ${
            canUndo ? 'bg-[#222] hover:bg-[#333] border-[#444] text-[#D1D1D1]' : 'bg-[#111] border-[#222] text-[#555] cursor-not-allowed'
          }`}
          title={t.undo}
        >
          <Undo2 className="w-3.5 h-3.5" />
        </button>

        <button
          onClick={onRedo}
          disabled={!canRedo}
          className={`px-2 py-1 rounded-sm text-xs font-mono uppercase border transition-colors ${
            canRedo ? 'bg-[#222] hover:bg-[#333] border-[#444] text-[#D1D1D1]' : 'bg-[#111] border-[#222] text-[#555] cursor-not-allowed'
          }`}
          title={t.redo}
        >
          <Redo2 className="w-3.5 h-3.5" />
        </button>

        <div className="h-4 w-[1px] bg-[#333]" />

        <label className="flex items-center space-x-1 px-2 py-1 rounded-sm text-xs font-mono uppercase bg-[#222] hover:bg-[#333] border border-[#444] text-[#D1D1D1] cursor-pointer transition-colors">
          <Upload className="w-3.5 h-3.5 text-[#888]" />
          <span>{t.import}</span>
          <input type="file" accept=".json,.cforge.json" onChange={handleImportJSON} className="hidden" />
        </label>

        <div className="relative">
          <button
            onClick={() => setShowExportMenu(!showExportMenu)}
            className="flex items-center space-x-1 px-2.5 py-1 rounded-sm text-xs font-mono uppercase bg-[#222] hover:bg-[#333] border border-[#444] text-[#D1D1D1] transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-[#888]" />
            <span>{t.export}</span>
          </button>

          {showExportMenu && (
            <div className="absolute right-0 mt-1 w-52 bg-[#111112] border border-[#333] rounded-sm shadow-2xl py-1 z-50">
              <button
                onClick={handleExportKiCad}
                className="w-full text-left px-3 py-1.5 text-xs font-mono text-[#D1D1D1] hover:bg-[#1A1A1B] hover:text-[#00FF00] flex items-center space-x-2"
              >
                <FileCode2 className="w-3.5 h-3.5 text-[#00FF00]" />
                <span>Export KiCad (.kicad_sch)</span>
              </button>
              <button
                onClick={handleExportJSON}
                className="w-full text-left px-3 py-1.5 text-xs font-mono text-[#D1D1D1] hover:bg-[#1A1A1B] hover:text-[#00FF00] flex items-center space-x-2"
              >
                <Download className="w-3.5 h-3.5 text-[#F27D26]" />
                <span>Export Project (.cforge)</span>
              </button>
            </div>
          )}
        </div>

        <div className="h-4 w-[1px] bg-[#333]" />

        <button
          onClick={onRunERC}
          className="flex items-center space-x-1 px-3 py-1 rounded-sm text-xs font-mono uppercase bg-[#1A1A1D] border border-[#F27D26]/60 text-[#F27D26] hover:bg-[#251D18] transition-colors font-bold"
          title={t.runCheck}
        >
          <ShieldAlert className="w-3.5 h-3.5 text-[#F27D26]" />
          <span>ERC</span>
        </button>

        <button
          onClick={handleExportKiCad}
          className="px-3 py-1 bg-[#00FF00] hover:bg-[#00DD00] text-[#0A0A0B] font-bold text-xs font-mono uppercase rounded-sm transition-colors shadow-[0_0_10px_rgba(0,255,0,0.2)]"
        >
          Export KiCad
        </button>
      </div>

      {/* Right status & settings controls */}
      <div className="flex items-center space-x-3">
        {/* AI Online Indicator */}
        <div
          onClick={onOpenSettings}
          className="flex items-center space-x-2 px-2 py-1 bg-[#1A1A1B] border border-[#333] rounded-sm cursor-pointer hover:border-[#00FF00]/50 transition-colors"
          title="Click to toggle or configure AI provider"
        >
          <div className="w-2 h-2 rounded-full bg-[#00FF00] shadow-[0_0_8px_#00FF00] animate-pulse" />
          <span className="text-[10px] text-[#777] uppercase font-mono tracking-widest font-bold">
            {aiSettings.provider === 'gemini' ? 'AI ONLINE' : 'LOCAL AI'}
          </span>
        </div>

        {/* Language Selector */}
        <div className="flex items-center space-x-1 bg-[#0A0A0B] border border-[#222] rounded-sm p-0.5">
          <Globe className="w-3.5 h-3.5 text-[#666] ml-1" />
          <button
            onClick={() => onSelectLanguage('en')}
            className={`px-1.5 py-0.5 rounded-sm text-[10px] font-mono transition-colors ${
              language === 'en' ? 'bg-[#222] text-[#00FF00] font-bold' : 'text-[#666] hover:text-[#CCC]'
            }`}
          >
            EN
          </button>
          <button
            onClick={() => onSelectLanguage('bm')}
            className={`px-1.5 py-0.5 rounded-sm text-[10px] font-mono transition-colors ${
              language === 'bm' ? 'bg-[#222] text-[#00FF00] font-bold' : 'text-[#666] hover:text-[#CCC]'
            }`}
          >
            BM
          </button>
        </div>

        {/* Settings button */}
        <button
          onClick={onOpenSettings}
          className="p-1 rounded-sm text-[#888] hover:text-white hover:bg-[#222] transition-colors border border-transparent hover:border-[#333]"
          title={t.settings}
        >
          <Settings className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
}
