'use client';

import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, 
  Send, 
  Sparkles, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Terminal, 
  Loader2, 
  RotateCcw,
  Zap
} from 'lucide-react';
import { ProjectData, Language, AISettings, AIProposalOperation } from '@/lib/types/eda';
import { TRANSLATIONS } from '@/lib/i18n';
import { GeminiProvider, LocalAIProvider } from '@/lib/ai/aiProvider';
import { getStoredSkills } from '@/lib/eda/skillsEngine';

import { generateId, generateCoordinates } from '@/lib/utils/idGenerator';

interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  proposal?: AIProposalOperation;
}

interface RightSidebarProps {
  project: ProjectData;
  onUpdateProject: (p: ProjectData) => void;
  language: Language;
  aiSettings: AISettings;
}

export function RightSidebar({
  project,
  onUpdateProject,
  language,
  aiSettings,
}: RightSidebarProps) {
  const t = TRANSLATIONS[language];
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'm1',
      sender: 'ai',
      text: `Hello! I am CircuitForge AI Engineering Assistant. I am ready to help you plan, calculate, review, and modify your hardware design for **${project.name}**. What would you like to build or analyze?`,
      timestamp: '10:00 AM',
    },
  ]);

  const [inputPrompt, setInputPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [activeProposal, setActiveProposal] = useState<AIProposalOperation | null>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const promptSuggestions = [
    'Tambah USB-C power input',
    'Calculate LDO regulator thermal dissipation',
    'Add SSD1306 0.96 OLED display via I2C',
    'Detect potential pin assignment conflicts',
  ];

  const handleSendMessage = async (customText?: string) => {
    const textToSend = customText || inputPrompt;
    if (!textToSend.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: generateId('msg_user'),
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputPrompt('');
    setIsLoading(true);

    // Gather active skills
    const activeSkills = getStoredSkills().filter((s) => s.enabled);
    const activeSkillRules = activeSkills.map((s) => `[${s.name}]: ${s.promptRules}`);

    // Call Provider
    const provider = aiSettings.provider === 'local' ? new LocalAIProvider() : new GeminiProvider();
    const response = await provider.sendMessage(textToSend, project, {
      localEndpoint: aiSettings.localEndpoint,
      customApiKey: aiSettings.customApiKey,
      provider: aiSettings.provider,
      model: aiSettings.model,
      activeSkillRules,
    });

    setIsLoading(false);

    const aiMsg: ChatMessage = {
      id: generateId('msg_ai'),
      sender: 'ai',
      text: response.text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      proposal: response.proposal,
    };

    setMessages((prev) => [...prev, aiMsg]);

    if (response.proposal) {
      setActiveProposal(response.proposal);
    }
  };

  const handleApproveProposal = (proposal: AIProposalOperation) => {
    let updated = { ...project };

    if (proposal.action === 'add_component' && proposal.payload) {
      const newComp = {
        id: generateId('comp'),
        ref: proposal.payload.ref || 'U_AI',
        name: proposal.payload.name || 'AI Added Component',
        manufacturer: proposal.payload.manufacturer || 'Generic',
        partNumber: proposal.payload.partNumber || 'PART-001',
        category: proposal.payload.category || 'MCU',
        package: proposal.payload.package || 'SMD',
        value: proposal.payload.value || '',
        description: proposal.payload.description || 'Added by CircuitForge AI',
        symbolId: 'sym_gen',
        pins: proposal.payload.pins || [],
      };
      updated.components = [...updated.components, newComp];
    } else if (proposal.action === 'add_block' && proposal.payload) {
      const coords = generateCoordinates(400, 200);
      const newBlock = {
        id: generateId('blk'),
        name: proposal.payload.name || 'New Block',
        type: proposal.payload.type || 'Subsystem',
        x: coords.x,
        y: coords.y,
        width: 180,
        height: 90,
        inputs: proposal.payload.inputs || [],
        outputs: proposal.payload.outputs || [],
        voltageRail: proposal.payload.voltageRail || '3.3V',
        description: proposal.payload.description || 'Generated block',
      };
      updated.blocks = [...updated.blocks, newBlock];
    } else if (proposal.action === 'add_power_rail' && proposal.payload) {
      const newRail = {
        id: generateId('pr'),
        name: proposal.payload.name || 'VCC Rail',
        voltage: proposal.payload.voltage || 3.3,
        estimatedCurrent: proposal.payload.estimatedCurrent || 200,
        powerSource: proposal.payload.powerSource || 'LDO Output',
      };
      updated.powerRails = [...updated.powerRails, newRail];
    } else if (proposal.action === 'connect_blocks' && proposal.payload) {
      const { sourceBlockId, targetBlockId, netName } = proposal.payload;
      if (sourceBlockId && targetBlockId) {
        const newConn = {
          id: generateId('conn_ai'),
          sourceBlockId,
          targetBlockId,
          netName: netName || 'AI_BUS',
        };
        updated.blockConnections = [...updated.blockConnections, newConn];
      }
    } else if (proposal.action === 'modify_circuit' && proposal.payload) {
      if (proposal.payload.mainController) {
        updated.mainController = proposal.payload.mainController;
      }
      if (proposal.payload.powerSource) {
        updated.powerSource = proposal.payload.powerSource;
      }
      if (proposal.payload.name) {
        updated.name = proposal.payload.name;
      }
    }

    // Append AI activity log
    updated.aiLog = [
      ...updated.aiLog,
      {
        id: generateId('log'),
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        action: proposal.title,
        details: proposal.description,
        type: 'ai',
      },
    ];

    onUpdateProject(updated);
    setActiveProposal(null);

    // Add confirmation chat
    setMessages((prev) => [
      ...prev,
      {
        id: generateId('msg_sys'),
        sender: 'ai',
        text: `Applied change: **${proposal.title}**. Project updated and validated successfully.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
  };

  return (
    <aside className="w-80 bg-[#111112] border-l border-[#222] flex flex-col shrink-0 select-none">
      {/* Header */}
      <div className="p-3 border-b border-[#222] flex items-center justify-between bg-[#0F0F10]">
        <div className="flex items-center space-x-2">
          <span className="font-bold text-xs uppercase tracking-widest text-[#AAA] font-mono">
            {t.aiAssistant}
          </span>
        </div>
        <div className="flex items-center space-x-2">
          <span className="text-[10px] font-mono px-1.5 py-0.5 rounded-sm bg-[#1A1A1B] border border-[#333] text-[#00FF00]">
            GEMINI 3.6
          </span>
          <div className="w-2 h-2 bg-[#00FF00] rounded-full shadow-[0_0_8px_#00FF00]" />
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-3 space-y-3 font-sans">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col ${
              msg.sender === 'user' ? 'items-end' : 'items-start'
            }`}
          >
            <div
              className={`max-w-[95%] p-3 rounded-sm text-xs leading-relaxed border-l-2 ${
                msg.sender === 'user'
                  ? 'bg-[#1A1A1B] border-[#444] text-[#CCC]'
                  : 'bg-[#131F15] border-[#00FF00] text-[#CCC]'
              }`}
            >
              <div className="text-[10px] font-mono font-bold uppercase mb-1 tracking-wider text-[#777]">
                {msg.sender === 'user' ? 'USER' : 'ASSISTANT'}
              </div>
              <p className="whitespace-pre-wrap">{msg.text}</p>
              <div className="text-[9px] opacity-50 text-right mt-1 font-mono text-[#666]">
                {msg.timestamp}
              </div>
            </div>

            {/* Structured Proposal UI Card */}
            {msg.proposal && (
              <div className="mt-2 w-full bg-[#0A0A0B] border border-[#00FF00]/40 rounded-sm p-3 shadow-2xl">
                <div className="flex items-center space-x-1.5 text-xs font-mono font-bold text-[#00FF00] mb-1 uppercase tracking-wider">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Proposed Engineering Modification</span>
                </div>
                <div className="text-xs text-white font-bold mb-1">{msg.proposal.title}</div>
                <div className="text-[11px] text-[#888] mb-2">{msg.proposal.description}</div>

                <div className="flex items-center space-x-2 pt-2 border-t border-[#222]">
                  <button
                    onClick={() => handleApproveProposal(msg.proposal!)}
                    className="flex-1 bg-[#00FF00] hover:bg-[#00DD00] text-[#000] text-[10px] font-bold font-mono uppercase py-2 rounded-sm transition-colors flex items-center justify-center space-x-1 shadow-[0_0_10px_rgba(0,255,0,0.15)]"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Apply Modifications</span>
                  </button>
                  <button
                    onClick={() => setActiveProposal(null)}
                    className="px-3 py-2 bg-[#222] hover:bg-[#333] text-[#AAA] text-[10px] font-mono uppercase rounded-sm border border-[#444] transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </div>
        ))}

        {isLoading && (
          <div className="flex items-center space-x-2 text-xs text-[#00FF00] bg-[#131F15] p-3 rounded-sm border border-[#00FF00]/30 animate-pulse font-mono">
            <Loader2 className="w-3.5 h-3.5 animate-spin text-[#00FF00]" />
            <span>AI ANALYZING SCHEMATIC & POWER TREES...</span>
          </div>
        )}

        <div ref={chatEndRef} />
      </div>

      {/* Prompt Suggestions */}
      <div className="p-2 border-t border-[#222] bg-[#0F0F10]">
        <div className="text-[10px] font-mono text-[#555] uppercase mb-1.5 font-bold tracking-widest">
          Suggested Prompts
        </div>
        <div className="flex flex-wrap gap-1.5">
          {promptSuggestions.map((prompt, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(prompt)}
              className="text-[10px] font-mono bg-[#1A1A1B] hover:bg-[#222] text-[#888] hover:text-[#00FF00] px-2 py-1 rounded-sm border border-[#333] transition-colors text-left"
            >
              {prompt}
            </button>
          ))}
        </div>
      </div>

      {/* Input Form */}
      <div className="p-3 border-t border-[#222] bg-[#0F0F10]">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="flex items-center bg-[#1A1A1B] border border-[#333] px-3 py-1.5 rounded-sm focus-within:border-[#00FF00]/60 transition-colors"
        >
          <input
            type="text"
            value={inputPrompt}
            onChange={(e) => setInputPrompt(e.target.value)}
            placeholder="Ask AI Assistant..."
            className="bg-transparent border-none focus:outline-none text-xs w-full text-[#CCC] placeholder-[#555] font-sans"
          />
          <button
            type="submit"
            disabled={!inputPrompt.trim() || isLoading}
            className="text-[#666] hover:text-[#00FF00] disabled:text-[#333] transition-colors ml-1"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </aside>
  );
}
