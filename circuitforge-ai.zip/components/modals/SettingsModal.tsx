'use client';

import React, { useState } from 'react';
import { X, Settings as SettingsIcon, Bot, CircuitBoard, Check, Globe } from 'lucide-react';
import { AISettings, EDASettings, Language } from '@/lib/types/eda';
import { TRANSLATIONS } from '@/lib/i18n';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  aiSettings: AISettings;
  onUpdateAISettings: (s: AISettings) => void;
  edaSettings: EDASettings;
  onUpdateEDASettings: (s: EDASettings) => void;
  language: Language;
  onSelectLanguage: (lang: Language) => void;
}

export function SettingsModal({
  isOpen,
  onClose,
  aiSettings,
  onUpdateAISettings,
  edaSettings,
  onUpdateEDASettings,
  language,
  onSelectLanguage,
}: SettingsModalProps) {
  const t = TRANSLATIONS[language];
  const [localAi, setLocalAi] = useState<AISettings>({ ...aiSettings });
  const [localEda, setLocalEda] = useState<EDASettings>({ ...edaSettings });
  const [savedSuccess, setSavedSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSave = () => {
    onUpdateAISettings(localAi);
    onUpdateEDASettings(localEda);
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 1000);
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-xl max-w-lg w-full p-6 text-slate-100 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-100 p-1 rounded-lg hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center space-x-2 text-slate-100 text-base font-bold mb-6 border-b border-slate-800 pb-3">
          <SettingsIcon className="w-5 h-5 text-emerald-400" />
          <span>CircuitForge AI Platform Settings</span>
        </div>

        <div className="space-y-6 max-h-[70vh] overflow-y-auto pr-1">
          {/* Section 1: AI Provider & API Keys */}
          <div className="space-y-3">
            <div className="flex items-center space-x-2 text-xs font-mono font-semibold text-emerald-400 uppercase">
              <Bot className="w-4 h-4" />
              <span>AI Engine & API Keys Configuration</span>
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">AI Provider Mode</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setLocalAi({ ...localAi, provider: 'gemini' })}
                  className={`p-2.5 rounded-lg border text-xs font-semibold flex items-center justify-center space-x-2 transition-colors ${
                    localAi.provider === 'gemini'
                      ? 'bg-emerald-950/80 border-emerald-500 text-emerald-300'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:bg-slate-800'
                  }`}
                >
                  <span>Gemini AI (Default / Custom Key)</span>
                </button>

                <button
                  onClick={() => setLocalAi({ ...localAi, provider: 'openai' })}
                  className={`p-2.5 rounded-lg border text-xs font-semibold flex items-center justify-center space-x-2 transition-colors ${
                    localAi.provider === 'openai'
                      ? 'bg-blue-950/80 border-blue-500 text-blue-300'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:bg-slate-800'
                  }`}
                >
                  <span>OpenAI</span>
                </button>

                <button
                  onClick={() => setLocalAi({ ...localAi, provider: 'deepseek' })}
                  className={`p-2.5 rounded-lg border text-xs font-semibold flex items-center justify-center space-x-2 transition-colors ${
                    localAi.provider === 'deepseek'
                      ? 'bg-purple-950/80 border-purple-500 text-purple-300'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:bg-slate-800'
                  }`}
                >
                  <span>DeepSeek R1</span>
                </button>

                <button
                  onClick={() => setLocalAi({ ...localAi, provider: 'local' })}
                  className={`p-2.5 rounded-lg border text-xs font-semibold flex items-center justify-center space-x-2 transition-colors ${
                    localAi.provider === 'local'
                      ? 'bg-indigo-950/80 border-indigo-500 text-indigo-300'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:bg-slate-800'
                  }`}
                >
                  <span>Offline (Local Ollama)</span>
                </button>
              </div>
            </div>

            {/* Custom API Key Input */}
            {localAi.provider !== 'local' && (
              <div className="space-y-2 pt-1">
                <div>
                  <label className="block text-xs font-mono text-emerald-400 mb-1 uppercase">
                    Custom AI API Key (Optional)
                  </label>
                  <input
                    type="password"
                    value={localAi.customApiKey || ''}
                    onChange={(e) => setLocalAi({ ...localAi, customApiKey: e.target.value })}
                    placeholder="Leave empty to use AI Studio default GEMINI_API_KEY"
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 font-mono focus:outline-none focus:border-emerald-500"
                  />
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    Your key is saved locally in browser memory and sent securely via server proxy.
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-mono text-amber-400 mb-1 uppercase">
                    LCSC Component Search API Key (Optional)
                  </label>
                  <input
                    type="password"
                    value={localAi.lcscApiKey || ''}
                    onChange={(e) => setLocalAi({ ...localAi, lcscApiKey: e.target.value })}
                    placeholder="e.g. LCSC_API_KEY_xxxx"
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 font-mono focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs text-slate-400 mb-1">Target Model Alias</label>
                  <select
                    value={localAi.model}
                    onChange={(e) => setLocalAi({ ...localAi, model: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 font-mono focus:outline-none focus:border-emerald-500"
                  >
                    <option value="gemini-3.6-flash">gemini-3.6-flash (Recommended)</option>
                    <option value="gemini-1.5-pro">gemini-1.5-pro (Deep Hardware Reasoning)</option>
                    <option value="gpt-4o">gpt-4o (OpenAI Compatible)</option>
                    <option value="deepseek-r1">deepseek-r1 (DeepSeek Reasoning)</option>
                  </select>
                </div>
              </div>
            )}

            {localAi.provider === 'local' && (
              <div>
                <label className="block text-xs text-slate-400 mb-1">Local Ollama Endpoint URL</label>
                <input
                  type="text"
                  value={localAi.localEndpoint}
                  onChange={(e) => setLocalAi({ ...localAi, localEndpoint: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 font-mono focus:outline-none focus:border-indigo-500"
                  placeholder="http://localhost:11434"
                />
                <span className="text-[10px] text-slate-500 mt-1 block">
                  Intended for local Ollama server (e.g. llama3 / qwen2.5-coder).
                </span>
              </div>
            )}
          </div>


          {/* Section 2: EDA Defaults */}
          <div className="space-y-3 pt-4 border-t border-slate-800">
            <div className="flex items-center space-x-2 text-xs font-mono font-semibold text-cyan-400 uppercase">
              <CircuitBoard className="w-4 h-4" />
              <span>EDA Canvas & Tooling</span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-slate-400 mb-1">Units</label>
                <select
                  value={localEda.defaultUnits}
                  onChange={(e) => setLocalEda({ ...localEda, defaultUnits: e.target.value as 'mm' | 'mil' })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                >
                  <option value="mm">Metric (mm)</option>
                  <option value="mil">Imperial (mil / thou)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs text-slate-400 mb-1">Grid Size (px)</label>
                <input
                  type="number"
                  value={localEda.gridSize}
                  onChange={(e) => setLocalEda({ ...localEda, gridSize: Number(e.target.value) })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 font-mono focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">KiCad CLI Executable Path</label>
              <input
                type="text"
                value={localEda.kicadPath}
                onChange={(e) => setLocalEda({ ...localEda, kicadPath: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 font-mono focus:outline-none focus:border-cyan-500"
                placeholder="/usr/bin/kicad-cli"
              />
            </div>
          </div>

          {/* Section 3: Language */}
          <div className="space-y-3 pt-4 border-t border-slate-800">
            <div className="flex items-center space-x-2 text-xs font-mono font-semibold text-amber-400 uppercase">
              <Globe className="w-4 h-4" />
              <span>Language Preference</span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => onSelectLanguage('en')}
                className={`p-2 rounded-lg border text-xs font-semibold transition-colors ${
                  language === 'en'
                    ? 'bg-amber-950/80 border-amber-500 text-amber-300'
                    : 'bg-slate-950 border-slate-800 text-slate-400'
                }`}
              >
                English
              </button>
              <button
                onClick={() => onSelectLanguage('bm')}
                className={`p-2 rounded-lg border text-xs font-semibold transition-colors ${
                  language === 'bm'
                    ? 'bg-amber-950/80 border-amber-500 text-amber-300'
                    : 'bg-slate-950 border-slate-800 text-slate-400'
                }`}
              >
                Bahasa Melayu
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between mt-6 pt-4 border-t border-slate-800">
          <span className="text-[11px] text-slate-500 font-mono">CircuitForge AI v1.0.0</span>
          <button
            onClick={handleSave}
            className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold rounded-lg text-xs flex items-center space-x-1.5 transition-colors"
          >
            {savedSuccess ? <Check className="w-4 h-4" /> : null}
            <span>{savedSuccess ? 'Saved!' : 'Save Settings'}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
