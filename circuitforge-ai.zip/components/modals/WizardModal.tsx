'use client';

import React, { useState } from 'react';
import { 
  X, 
  ArrowRight, 
  ArrowLeft, 
  Cpu, 
  Zap, 
  Layers, 
  Sparkles, 
  Check, 
  Loader2,
  Wand2
} from 'lucide-react';
import { ProjectData } from '@/lib/types/eda';

interface WizardModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateProject: (project: ProjectData) => void;
}

export function WizardModal({ isOpen, onClose, onCreateProject }: WizardModalProps) {
  const [step, setStep] = useState(1);
  const [projectName, setProjectName] = useState('ESP32-S3 Smart Sensor');
  const [deviceDesc, setDeviceDesc] = useState('Portable IoT sensor node with battery charging, LoRa transceiver, and OLED display.');
  const [powerSource, setPowerSource] = useState('USB-C');
  const [mainController, setMainController] = useState('ESP32-S3');
  const [selectedInterfaces, setSelectedInterfaces] = useState<string[]>(['USB', 'I2C', 'SPI', 'WiFi', 'LoRa']);
  const [isAiGenerating, setIsAiGenerating] = useState(false);

  if (!isOpen) return null;

  const powerOptions = [
    'USB-C', 'USB-A', 'Li-Ion', 'Li-Po', '18650 Cell', '2S Battery', '3S Battery', '5V Adapter', '12V Adapter', 'Custom'
  ];

  const mcuOptions = [
    'ESP32', 'ESP32-S3', 'RP2040', 'STM32', 'Arduino (ATmega328P)', 'Raspberry Pi Pico', 'Custom MCU'
  ];

  const interfaceOptions = [
    'USB', 'UART', 'I2C', 'SPI', 'CAN', 'RS485', 'Ethernet', 'WiFi', 'Bluetooth', 'LoRa', 'GPIO'
  ];

  const toggleInterface = (iface: string) => {
    if (selectedInterfaces.includes(iface)) {
      setSelectedInterfaces(selectedInterfaces.filter(i => i !== iface));
    } else {
      setSelectedInterfaces([...selectedInterfaces, iface]);
    }
  };

  const handleFinishWizard = async () => {
    setIsAiGenerating(true);

    try {
      const res = await fetch('/api/ai/architect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          projectName,
          deviceDescription: deviceDesc,
          powerSource,
          mainController,
          interfaces: selectedInterfaces,
        }),
      });

      let aiBlocks = [];
      let aiComponents = [];
      let aiPowerRails = [];
      let aiWarnings = [];

      if (res.ok) {
        const data = await res.json();
        aiBlocks = data.blocks || [];
        aiComponents = data.components || [];
        aiPowerRails = data.powerRails || [];
        aiWarnings = data.warnings || [];
      }

      // Default fallback blocks if AI structure is sparse
      if (aiBlocks.length === 0) {
        aiBlocks = [
          { id: 'b1', name: powerSource + ' Power Input', type: 'Power', x: 100, y: 150, width: 160, height: 80, inputs: [], outputs: [{ id: 'o1', name: '5V', type: 'power' }], voltageRail: '5V', description: 'Power source' },
          { id: 'b2', name: '3.3V LDO Regulator', type: 'Regulator', x: 300, y: 150, width: 160, height: 80, inputs: [{ id: 'i1', name: '5V', type: 'power' }], outputs: [{ id: 'o2', name: '3.3V', type: 'power' }], voltageRail: '3.3V', description: 'System 3.3V supply' },
          { id: 'b3', name: mainController + ' Core', type: 'MCU', x: 500, y: 150, width: 180, height: 100, inputs: [{ id: 'i2', name: '3.3V', type: 'power' }], outputs: [], voltageRail: '3.3V', description: 'Main controller' },
        ];
      }

      const newProject: ProjectData = {
        version: '1.0',
        id: 'proj_' + Date.now(),
        name: projectName,
        description: deviceDesc,
        powerSource,
        mainController,
        interfaces: selectedInterfaces,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        status: 'Draft',
        blocks: aiBlocks.map((b: any, idx: number) => ({
          ...b,
          x: b.x || (100 + idx * 200),
          y: b.y || 150,
          width: 170,
          height: 90,
          inputs: b.inputs || [],
          outputs: b.outputs || [],
        })),
        blockConnections: [],
        components: aiComponents.map((c: any, idx: number) => ({
          id: 'comp_' + idx,
          ref: c.ref || 'U' + (idx + 1),
          name: c.name || 'Component',
          manufacturer: c.manufacturer || 'Generic',
          partNumber: c.partNumber || 'PART-001',
          category: c.category || 'MCU',
          package: c.package || 'SMD',
          value: c.value || '',
          description: c.description || '',
          symbolId: 'sym_gen',
          pins: [],
        })),
        nets: [
          { id: 'net_3v3', name: '3V3', type: 'power', voltage: '3.3V', pins: [] },
          { id: 'net_gnd', name: 'GND', type: 'ground', voltage: '0V', pins: [] },
        ],
        powerRails: aiPowerRails.length > 0 ? aiPowerRails : [
          { id: 'pr_1', name: powerSource + ' Input', voltage: 5.0, estimatedCurrent: 500, powerSource },
          { id: 'pr_2', name: '3.3V System Rail', voltage: 3.3, estimatedCurrent: 300, powerSource: 'LDO Regulator' },
        ],
        warnings: aiWarnings,
        documents: [],
        aiLog: [
          {
            id: 'log_init',
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            action: 'Project Created',
            details: `Created project via Wizard: ${projectName} (${mainController})`,
            type: 'system',
          },
        ],
      };

      setIsAiGenerating(false);
      onCreateProject(newProject);
      onClose();
    } catch (e) {
      setIsAiGenerating(false);
      alert('Error creating project via AI wizard.');
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-xl max-w-2xl w-full p-6 text-slate-100 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-100 p-1 rounded-lg hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Wizard Header & Progress Bar */}
        <div className="mb-6">
          <div className="flex items-center space-x-2 text-emerald-400 text-xs font-mono font-semibold uppercase mb-1">
            <Wand2 className="w-4 h-4" />
            <span>CircuitForge AI Wizard — Step {step} of 6</span>
          </div>
          <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden mt-2">
            <div
              className="h-full bg-emerald-500 transition-all duration-300"
              style={{ width: `${(step / 6) * 100}%` }}
            />
          </div>
        </div>

        {/* Step 1: Project Name */}
        {step === 1 && (
          <div className="space-y-4">
            <h2 className="text-lg font-bold text-slate-100">Step 1: Name Your Project</h2>
            <p className="text-xs text-slate-400">Give your electronic device project a clear identifier.</p>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Project Name</label>
              <input
                type="text"
                value={projectName}
                onChange={(e) => setProjectName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-emerald-500"
                placeholder="e.g. ESP32-S3 Environmental Monitor"
              />
            </div>
          </div>
        )}

        {/* Step 2: Device Description */}
        {step === 2 && (
          <div className="space-y-4">
            <h2 className="text-lg font-bold text-slate-100">Step 2: Describe the Device Requirements</h2>
            <p className="text-xs text-slate-400">Describe what your device should do in plain language.</p>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Device Description</label>
              <textarea
                value={deviceDesc}
                onChange={(e) => setDeviceDesc(e.target.value)}
                rows={4}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-3 text-sm text-slate-100 focus:outline-none focus:border-emerald-500"
                placeholder="Describe power input, display, sensors, communications..."
              />
            </div>
          </div>
        )}

        {/* Step 3: Select Power Source */}
        {step === 3 && (
          <div className="space-y-4">
            <h2 className="text-lg font-bold text-slate-100">Step 3: Select Primary Power Source</h2>
            <p className="text-xs text-slate-400">Choose how the electronic hardware will be powered.</p>

            <div className="grid grid-cols-2 gap-2">
              {powerOptions.map((opt) => (
                <button
                  key={opt}
                  onClick={() => setPowerSource(opt)}
                  className={`p-3 rounded-lg border text-xs text-left transition-all ${
                    powerSource === opt
                      ? 'bg-emerald-950/80 border-emerald-500 text-emerald-300 font-semibold'
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  {opt}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Step 4: Main Controller */}
        {step === 4 && (
          <div className="space-y-4">
            <h2 className="text-lg font-bold text-slate-100">Step 4: Select Main MCU Controller</h2>
            <p className="text-xs text-slate-400">Select the primary microcontroller core or processor.</p>

            <div className="grid grid-cols-2 gap-2">
              {mcuOptions.map((mcu) => (
                <button
                  key={mcu}
                  onClick={() => setMainController(mcu)}
                  className={`p-3 rounded-lg border text-xs text-left transition-all ${
                    mainController === mcu
                      ? 'bg-emerald-950/80 border-emerald-500 text-emerald-300 font-semibold'
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  {mcu}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Step 5: Interfaces */}
        {step === 5 && (
          <div className="space-y-4">
            <h2 className="text-lg font-bold text-slate-100">Step 5: Peripheral Interfaces</h2>
            <p className="text-xs text-slate-400">Select communication buses and peripheral protocols required.</p>

            <div className="grid grid-cols-3 gap-2">
              {interfaceOptions.map((iface) => {
                const isSelected = selectedInterfaces.includes(iface);
                return (
                  <button
                    key={iface}
                    onClick={() => toggleInterface(iface)}
                    className={`p-2.5 rounded-lg border text-xs flex items-center justify-between transition-all ${
                      isSelected
                        ? 'bg-emerald-950/80 border-emerald-500 text-emerald-300 font-semibold'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:bg-slate-800'
                    }`}
                  >
                    <span>{iface}</span>
                    {isSelected && <Check className="w-3.5 h-3.5 text-emerald-400" />}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Step 6: AI Pre-Architect Confirmation */}
        {step === 6 && (
          <div className="space-y-4 text-center py-4">
            <div className="w-12 h-12 bg-emerald-950 border border-emerald-700/80 text-emerald-400 rounded-full flex items-center justify-center mx-auto mb-2">
              <Sparkles className="w-6 h-6 animate-pulse" />
            </div>
            <h2 className="text-xl font-bold text-slate-100">Ready to Generate Architecture</h2>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              CircuitForge AI will analyze your specifications and generate an initial block diagram, component list, power tree, and design warning check.
            </p>

            <div className="bg-slate-950 border border-slate-800 rounded-lg p-3 text-left text-xs space-y-1 font-mono text-slate-300">
              <div><strong className="text-slate-400">Project:</strong> {projectName}</div>
              <div><strong className="text-slate-400">Power:</strong> {powerSource}</div>
              <div><strong className="text-slate-400">MCU:</strong> {mainController}</div>
              <div><strong className="text-slate-400">Interfaces:</strong> {selectedInterfaces.join(', ')}</div>
            </div>
          </div>
        )}

        {/* Wizard Footer Controls */}
        <div className="flex items-center justify-between mt-8 pt-4 border-t border-slate-800">
          {step > 1 ? (
            <button
              onClick={() => setStep(step - 1)}
              disabled={isAiGenerating}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>
          ) : (
            <div />
          )}

          {step < 6 ? (
            <button
              onClick={() => setStep(step + 1)}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold rounded-lg text-xs flex items-center space-x-1.5 transition-colors"
            >
              <span>Next</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={handleFinishWizard}
              disabled={isAiGenerating}
              className="px-5 py-2 bg-emerald-500 hover:bg-emerald-400 disabled:bg-slate-800 text-slate-950 font-bold rounded-lg text-xs flex items-center space-x-2 transition-colors shadow-lg"
            >
              {isAiGenerating ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-slate-950" />
                  <span>Synthesizing Architecture...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Generate Project Architecture</span>
                </>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
