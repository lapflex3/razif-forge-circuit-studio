'use client';

import React, { useState } from 'react';
import { 
  CircuitBoard, 
  Sparkles, 
  ZoomIn, 
  ZoomOut, 
  RotateCcw, 
  Trash2, 
  Zap, 
  Layers,
  Move,
  Loader2
} from 'lucide-react';
import { ProjectData, ComponentItem } from '@/lib/types/eda';

interface SchematicViewProps {
  project: ProjectData;
  onUpdateProject: (p: ProjectData) => void;
}

export function SchematicView({ project, onUpdateProject }: SchematicViewProps) {
  const [selectedCompId, setSelectedCompId] = useState<string | null>(null);
  const [zoom, setZoom] = useState(1);
  const [draggingCompId, setDraggingCompId] = useState<string | null>(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [isAiGenerating, setIsAiGenerating] = useState(false);

  const handleMouseDown = (e: React.MouseEvent, comp: ComponentItem) => {
    e.stopPropagation();
    setSelectedCompId(comp.id);
    setDraggingCompId(comp.id);
    setDragOffset({
      x: e.clientX - (comp.x || 100),
      y: e.clientY - (comp.y || 100),
    });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!draggingCompId) return;
    const newX = Math.max(20, Math.min(1400, e.clientX - dragOffset.x));
    const newY = Math.max(20, Math.min(800, e.clientY - dragOffset.y));

    const updatedComps = project.components.map((c) =>
      c.id === draggingCompId ? { ...c, x: newX, y: newY } : c
    );

    onUpdateProject({ ...project, components: updatedComps });
  };

  const handleMouseUp = () => {
    setDraggingCompId(null);
  };

  const handleGenerateSchematicAI = () => {
    setIsAiGenerating(true);
    setTimeout(() => {
      // Auto-arrange components into neat schematic grid
      const arranged = project.components.map((c, idx) => ({
        ...c,
        x: 100 + (idx % 3) * 260,
        y: 100 + Math.floor(idx / 3) * 200,
      }));

      onUpdateProject({ ...project, components: arranged });
      setIsAiGenerating(false);
    }, 1200);
  };

  return (
    <div
      className="flex-1 h-full bg-slate-950 flex flex-col select-none relative overflow-hidden"
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
    >
      {/* Top Bar Controls */}
      <div className="h-12 bg-slate-900 border-b border-slate-800 px-4 flex items-center justify-between shrink-0 z-10">
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-1.5 text-xs font-mono text-cyan-400 font-semibold uppercase">
            <CircuitBoard className="w-4 h-4" />
            <span>Functional Circuit Schematic Editor</span>
          </div>

          <div className="h-4 w-px bg-slate-800" />

          <button
            onClick={handleGenerateSchematicAI}
            disabled={isAiGenerating}
            className="px-3 py-1 bg-cyan-600 hover:bg-cyan-500 disabled:bg-slate-800 text-slate-950 font-bold rounded text-xs flex items-center space-x-1.5 transition-colors"
          >
            {isAiGenerating ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Sparkles className="w-3.5 h-3.5" />
            )}
            <span>Generate Schematic with AI</span>
          </button>
        </div>

        {/* Zoom */}
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setZoom(Math.max(0.5, zoom - 0.1))}
            className="p-1 rounded text-slate-400 hover:text-slate-100 hover:bg-slate-800"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <span className="text-xs font-mono text-slate-400 font-medium">
            {Math.round(zoom * 100)}%
          </span>
          <button
            onClick={() => setZoom(Math.min(2.0, zoom + 0.1))}
            className="p-1 rounded text-slate-400 hover:text-slate-100 hover:bg-slate-800"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Canvas */}
      <div
        className="flex-1 relative overflow-auto cursor-crosshair bg-[linear-gradient(to_right,#222225_1px,transparent_1px),linear-gradient(to_bottom,#222225_1px,transparent_1px)] [background-size:24px_24px] bg-[#070708]"
        style={{ transform: `scale(${zoom})`, transformOrigin: 'top left' }}
      >
        {/* Watermark Overlay */}
        <div className="watermark-overlay">
          <span>RazifSoftwares</span>
          <span className="text-[#888]">|</span>
          <span>Circuit Schematic Engine</span>
        </div>
        {/* SVG Wires */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none z-0">
          {project.nets.map((net, nIdx) => {
            if (net.pins.length < 2) return null;
            const pinsWithPos = net.pins.map((p) => {
              const comp = project.components.find((c) => c.id === p.componentId);
              return {
                x: (comp?.x || 100) + 100,
                y: (comp?.y || 100) + 60,
              };
            });

            return (
              <g key={net.id}>
                {pinsWithPos.slice(0, -1).map((pt1, pIdx) => {
                  const pt2 = pinsWithPos[pIdx + 1];
                  return (
                    <line
                      key={pIdx}
                      x1={pt1.x}
                      y1={pt1.y}
                      x2={pt2.x}
                      y2={pt2.y}
                      stroke={net.type === 'power' ? '#f59e0b' : net.type === 'ground' ? '#64748b' : '#38bdf8'}
                      strokeWidth="2"
                    />
                  );
                })}
              </g>
            );
          })}
        </svg>

        {/* Component Symbol Blocks */}
        {project.components.map((comp) => {
          const x = comp.x || 100;
          const y = comp.y || 100;
          const isSelected = comp.id === selectedCompId;

          return (
            <div
              key={comp.id}
              onMouseDown={(e) => handleMouseDown(e, comp)}
              style={{ left: `${x}px`, top: `${y}px` }}
              className={`absolute w-52 bg-slate-900 border-2 rounded-lg p-3 shadow-2xl transition-all cursor-grab active:cursor-grabbing z-10 ${
                isSelected
                  ? 'border-cyan-400 ring-2 ring-cyan-500/30'
                  : 'border-slate-800 hover:border-slate-700'
              }`}
            >
              {/* Reference & Name */}
              <div className="flex items-center justify-between border-b border-slate-800 pb-1.5 mb-2">
                <span className="text-xs font-mono font-bold text-amber-400">{comp.ref}</span>
                <span className="text-[10px] font-mono text-slate-400">{comp.package}</span>
              </div>

              <div className="text-xs font-bold text-slate-100">{comp.name}</div>
              <div className="text-[10px] font-mono text-slate-400">{comp.value || comp.partNumber}</div>

              {/* Symbol Pins */}
              <div className="mt-2 space-y-1 bg-slate-950 p-1.5 rounded border border-slate-800/80">
                {comp.pins?.slice(0, 5).map((pin) => (
                  <div key={pin.id} className="flex items-center justify-between text-[10px] font-mono text-slate-400">
                    <span className="text-slate-500">[{pin.number}]</span>
                    <span className="text-slate-200">{pin.name}</span>
                    <span className={`text-[9px] ${pin.type === 'ground' ? 'text-slate-500' : pin.type.includes('power') ? 'text-amber-400' : 'text-cyan-400'}`}>
                      {pin.type}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
