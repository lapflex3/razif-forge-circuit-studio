'use client';

import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  BrainCircuit, 
  Download, 
  Upload, 
  Plus, 
  Check, 
  Play, 
  FolderDown, 
  Cpu, 
  ShieldCheck, 
  Zap, 
  Layers, 
  Radio, 
  Flame, 
  FileCode, 
  CheckCircle2,
  Settings2,
  Trash2
} from 'lucide-react';
import { ProjectData, ProjectSkill } from '@/lib/types/eda';
import { getStoredSkills, saveCustomSkill, exportSkillsToJSON, runSkillMLAnalysis } from '@/lib/eda/skillsEngine';

interface SkillsViewProps {
  project: ProjectData;
  onUpdateProject: (p: ProjectData) => void;
}

export function SkillsView({ project, onUpdateProject }: SkillsViewProps) {
  const [skills, setSkills] = useState<ProjectSkill[]>(() => getStoredSkills());
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [analysisResult, setAnalysisResult] = useState<string | null>(null);
  const [runningSkillId, setRunningSkillId] = useState<string | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);

  // New Skill Form State
  const [newName, setNewName] = useState('Custom High-Speed Differential Pair Skill');
  const [newCat, setNewCat] = useState<ProjectSkill['category']>('pcb');
  const [newDesc, setNewDesc] = useState('Enforces 90-ohm USB 2.0 / USB 3.0 differential trace length matching and via guard spacing.');
  const [newRules, setNewRules] = useState('When routing USB D+ and D- signals, enforce matched line length within 0.5mm tolerance and maintain ground plane continuity under traces.');

  const categories = ['ALL', 'power', 'mcu', 'rf', 'erc', 'thermal', 'lcsc', 'pcb', 'custom'];

  const filteredSkills = skills.filter(
    (s) => selectedCategory === 'ALL' || s.category === selectedCategory
  );

  const handleToggleSkill = (skillId: string) => {
    const updated = skills.map((s) => (s.id === skillId ? { ...s, enabled: !s.enabled } : s));
    setSkills(updated);
  };

  const handleRunSkill = (skill: ProjectSkill) => {
    setRunningSkillId(skill.id);
    setAnalysisResult(null);
    setTimeout(() => {
      const res = runSkillMLAnalysis(skill, project);
      setAnalysisResult(res);
      setRunningSkillId(null);
    }, 600);
  };

  const handleExportSkillsLocalFolder = () => {
    exportSkillsToJSON(skills);
  };

  const handleCreateSkill = () => {
    if (!newName.trim()) return;
    const newSkill: ProjectSkill = {
      id: 'skill_custom_' + Date.now(),
      name: newName,
      category: newCat,
      description: newDesc,
      promptRules: newRules,
      author: 'User Custom Skill',
      version: '1.0.0',
      isSystem: false,
      enabled: true,
    };

    const updated = saveCustomSkill(newSkill);
    setSkills(updated);
    setShowAddModal(false);
  };

  const getCategoryIcon = (cat: ProjectSkill['category']) => {
    switch (cat) {
      case 'power': return <Zap className="w-4 h-4 text-[#00FF00]" />;
      case 'mcu': return <Cpu className="w-4 h-4 text-[#38BDF8]" />;
      case 'rf': return <Radio className="w-4 h-4 text-[#F59E0B]" />;
      case 'erc': return <ShieldCheck className="w-4 h-4 text-[#EF4444]" />;
      case 'thermal': return <Flame className="w-4 h-4 text-[#F97316]" />;
      case 'lcsc': return <FileCode className="w-4 h-4 text-[#F27D26]" />;
      case 'pcb': return <Layers className="w-4 h-4 text-[#A855F7]" />;
      default: return <Sparkles className="w-4 h-4 text-[#EC4899]" />;
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-[#111112] border border-[#222] p-5 rounded-sm">
        <div className="space-y-1">
          <div className="flex items-center space-x-2 text-xs font-mono font-bold text-[#00FF00] uppercase">
            <BrainCircuit className="w-4 h-4" />
            <span>AI ML & Project Skills Engine</span>
            <span className="text-[9px] font-mono font-bold tracking-wider px-1.5 py-0.5 bg-[#1F1713] text-[#F27D26] border border-[#F27D26]/40 rounded-sm uppercase ml-2">
              RazifSoftwares
            </span>
          </div>
          <h1 className="text-xl font-bold text-white uppercase font-mono tracking-tight">
            Hardware Design Skills & ML Analyzers
          </h1>
          <p className="text-xs text-[#888]">
            Manage domain-specific AI prompt skills, LCSC component rule checkers, and ML thermal/power design analyzers.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          {/* Save / Export Skills to Local Folder */}
          <button
            onClick={handleExportSkillsLocalFolder}
            className="px-3.5 py-2 bg-[#1F1713] hover:bg-[#2A1E17] text-[#F27D26] border border-[#F27D26]/60 font-mono font-bold text-xs uppercase rounded-sm flex items-center space-x-1.5 transition-colors"
            title="Download and save all project skills to local JSON folder"
          >
            <FolderDown className="w-4 h-4 text-[#F27D26]" />
            <span>Save Skills to Local Folder</span>
          </button>

          <button
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2 bg-[#00FF00] hover:bg-[#00DD00] text-[#0A0A0B] font-bold rounded-sm text-xs font-mono uppercase flex items-center space-x-1.5 transition-colors shadow-[0_0_10px_rgba(0,255,0,0.15)]"
          >
            <Plus className="w-4 h-4" />
            <span>New Custom Skill</span>
          </button>
        </div>
      </div>

      {/* Analysis Output Alert if present */}
      {analysisResult && (
        <div className="bg-[#151D18] border border-[#00FF00]/50 p-4 rounded-sm flex items-start space-x-3 shadow-xl">
          <CheckCircle2 className="w-5 h-5 text-[#00FF00] shrink-0 mt-0.5" />
          <div className="space-y-1">
            <div className="text-xs font-mono font-bold text-[#00FF00] uppercase">
              ML Analysis Output
            </div>
            <p className="text-xs text-[#DDD] font-mono">{analysisResult}</p>
          </div>
        </div>
      )}

      {/* Filter Tabs */}
      <div className="flex items-center space-x-2 overflow-x-auto pb-1 scrollbar-none bg-[#111112] p-2 rounded-sm border border-[#222]">
        <span className="text-xs font-mono text-[#666] uppercase font-bold px-2">Domain Filter:</span>
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3 py-1 rounded-sm text-xs font-mono font-bold uppercase transition-colors shrink-0 ${
              selectedCategory === cat
                ? 'bg-[#00FF00] text-[#0A0A0B]'
                : 'bg-[#1A1A1B] text-[#888] hover:text-white hover:bg-[#222]'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Skills Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredSkills.map((skill) => (
          <div
            key={skill.id}
            className={`bg-[#111112] border rounded-sm p-4 flex flex-col justify-between space-y-4 transition-all shadow-xl ${
              skill.enabled ? 'border-[#333] hover:border-[#00FF00]/50' : 'border-[#222] opacity-60'
            }`}
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  {getCategoryIcon(skill.category)}
                  <span className="text-[10px] font-mono font-bold uppercase px-2 py-0.5 bg-[#1A1A1B] text-[#888] rounded-sm border border-[#333]">
                    {skill.category}
                  </span>
                </div>

                <div className="flex items-center space-x-2">
                  {skill.isSystem ? (
                    <span className="text-[9px] font-mono font-bold text-[#00FF00] uppercase bg-[#112211] px-1.5 py-0.5 rounded-sm border border-[#00FF00]/30">
                      System ML
                    </span>
                  ) : (
                    <span className="text-[9px] font-mono text-[#F27D26] uppercase bg-[#221811] px-1.5 py-0.5 rounded-sm border border-[#F27D26]/30">
                      User Skill
                    </span>
                  )}

                  <input
                    type="checkbox"
                    checked={skill.enabled}
                    onChange={() => handleToggleSkill(skill.id)}
                    className="accent-[#00FF00] w-4 h-4 cursor-pointer"
                  />
                </div>
              </div>

              <h3 className="text-sm font-bold text-white font-mono">{skill.name}</h3>
              <p className="text-xs text-[#AAA]">{skill.description}</p>
            </div>

            {/* Prompt Rules Snippet */}
            <div className="bg-[#0A0A0B] p-2.5 rounded-sm border border-[#222] space-y-1">
              <div className="text-[10px] font-mono text-[#666] uppercase font-bold">
                Active Prompt Engineering Rules
              </div>
              <p className="text-[11px] font-mono text-[#888] line-clamp-3 italic">
                &quot;{skill.promptRules}&quot;
              </p>

            </div>

            <div className="pt-2 border-t border-[#222] flex items-center justify-between">
              <span className="text-[10px] font-mono text-[#555]">
                v{skill.version || '1.0'} • {skill.author}
              </span>

              <button
                onClick={() => handleRunSkill(skill)}
                disabled={runningSkillId === skill.id}
                className="px-3 py-1 bg-[#1A1A1B] hover:bg-[#222] text-[#00FF00] border border-[#00FF00]/40 rounded-sm text-xs font-mono font-bold uppercase flex items-center space-x-1 transition-colors disabled:opacity-50"
              >
                <Play className="w-3 h-3 text-[#00FF00]" />
                <span>{runningSkillId === skill.id ? 'Running...' : 'Run ML Test'}</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Add Custom Skill Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-[#0A0A0B]/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#111112] border border-[#333] rounded-sm p-5 max-w-lg w-full space-y-4 shadow-2xl">
            <h3 className="text-sm font-mono font-bold text-white uppercase tracking-wider border-b border-[#222] pb-2">
              Create New Custom Hardware Skill
            </h3>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-mono text-[#888] mb-1 uppercase">Skill Name</label>
                <input
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="w-full bg-[#1A1A1B] border border-[#333] rounded-sm px-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#00FF00]"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-[#888] mb-1 uppercase">Domain Category</label>
                <select
                  value={newCat}
                  onChange={(e) => setNewCat(e.target.value as any)}
                  className="w-full bg-[#1A1A1B] border border-[#333] rounded-sm px-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#00FF00]"
                >
                  <option value="power">Power Tree & Voltage Rails</option>
                  <option value="mcu">MCU & Controller Logic</option>
                  <option value="rf">RF & Antenna Matching</option>
                  <option value="erc">Electrical Rules Check (ERC)</option>
                  <option value="thermal">Thermal Dissipation</option>
                  <option value="lcsc">LCSC Part Procurement</option>
                  <option value="pcb">PCB Layout & Routing</option>
                  <option value="custom">Custom General Domain</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-mono text-[#888] mb-1 uppercase">Description</label>
                <input
                  type="text"
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  className="w-full bg-[#1A1A1B] border border-[#333] rounded-sm px-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#00FF00]"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-[#00FF00] mb-1 uppercase">
                  System Prompt Engineering Rules
                </label>
                <textarea
                  value={newRules}
                  onChange={(e) => setNewRules(e.target.value)}
                  rows={4}
                  className="w-full bg-[#1A1A1B] border border-[#00FF00]/40 rounded-sm p-2 text-xs text-white font-mono focus:outline-none focus:border-[#00FF00]"
                />
              </div>
            </div>

            <div className="flex items-center justify-end space-x-2 pt-2 border-t border-[#222]">
              <button
                onClick={() => setShowAddModal(false)}
                className="px-3 py-1.5 bg-[#222] text-[#AAA] rounded-sm text-xs font-mono uppercase border border-[#444]"
              >
                Cancel
              </button>
              <button
                onClick={handleCreateSkill}
                className="px-4 py-1.5 bg-[#00FF00] hover:bg-[#00DD00] text-[#0A0A0B] font-bold rounded-sm text-xs font-mono uppercase"
              >
                Save Skill
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
