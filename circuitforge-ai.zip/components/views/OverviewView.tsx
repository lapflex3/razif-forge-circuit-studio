'use client';

import React from 'react';
import { 
  LayoutDashboard, 
  Cpu, 
  Zap, 
  Boxes, 
  Network, 
  ShieldAlert, 
  Clock, 
  FileCode2, 
  Table, 
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { ProjectData } from '@/lib/types/eda';
import { ViewType } from '@/components/layout/LeftSidebar';

interface OverviewViewProps {
  project: ProjectData;
  onNavigate: (view: ViewType) => void;
  onRunERC: () => void;
}

export function OverviewView({ project, onNavigate, onRunERC }: OverviewViewProps) {
  const criticalCount = project.warnings.filter(w => w.severity === 'CRITICAL').length;
  const warningCount = project.warnings.filter(w => w.severity === 'WARNING').length;

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-xs font-mono font-semibold text-emerald-400 uppercase mb-1">
            <LayoutDashboard className="w-4 h-4" />
            <span>Project Architecture Overview</span>
          </div>
          <h1 className="text-xl font-bold text-slate-100">{project.name}</h1>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">{project.description}</p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={onRunERC}
            className="px-3.5 py-2 bg-amber-950/80 border border-amber-800 text-amber-300 hover:bg-amber-900 font-semibold rounded-xl text-xs flex items-center space-x-1.5 transition-colors"
          >
            <ShieldAlert className="w-4 h-4 text-amber-400" />
            <span>ERC Check ({warningCount} Warnings)</span>
          </button>
          <button
            onClick={() => onNavigate('blocks')}
            className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold rounded-xl text-xs flex items-center space-x-1.5 transition-colors shadow-lg"
          >
            <span>Edit Block Diagram</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
        <div
          onClick={() => onNavigate('blocks')}
          className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 cursor-pointer hover:border-slate-700 transition-colors"
        >
          <div className="text-[10px] font-mono uppercase text-slate-400">Blocks</div>
          <div className="text-2xl font-bold text-slate-100 mt-1">{project.blocks.length}</div>
          <div className="text-[10px] text-slate-400">Functional Nodes</div>
        </div>

        <div
          onClick={() => onNavigate('components')}
          className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 cursor-pointer hover:border-slate-700 transition-colors"
        >
          <div className="text-[10px] font-mono uppercase text-slate-400">Components</div>
          <div className="text-2xl font-bold text-slate-100 mt-1">{project.components.length}</div>
          <div className="text-[10px] text-slate-400">Bill of Materials</div>
        </div>

        <div
          onClick={() => onNavigate('netlist')}
          className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 cursor-pointer hover:border-slate-700 transition-colors"
        >
          <div className="text-[10px] font-mono uppercase text-slate-400">Nets</div>
          <div className="text-2xl font-bold text-slate-100 mt-1">{project.nets.length}</div>
          <div className="text-[10px] text-slate-400">Circuit Traces</div>
        </div>

        <div
          onClick={() => onNavigate('power')}
          className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 cursor-pointer hover:border-slate-700 transition-colors"
        >
          <div className="text-[10px] font-mono uppercase text-slate-400">Power Rails</div>
          <div className="text-2xl font-bold text-slate-100 mt-1">{project.powerRails.length}</div>
          <div className="text-[10px] text-slate-400">Voltage Tree</div>
        </div>

        <div
          onClick={() => onNavigate('aiReview')}
          className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 cursor-pointer hover:border-slate-700 transition-colors"
        >
          <div className="text-[10px] font-mono uppercase text-slate-400">ERC Findings</div>
          <div className="text-2xl font-bold text-amber-400 mt-1">{project.warnings.length}</div>
          <div className="text-[10px] text-slate-400">{criticalCount} Critical</div>
        </div>

        <div
          onClick={() => onNavigate('documents')}
          className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 cursor-pointer hover:border-slate-700 transition-colors"
        >
          <div className="text-[10px] font-mono uppercase text-slate-400">Datasheets</div>
          <div className="text-2xl font-bold text-cyan-400 mt-1">{project.documents.length}</div>
          <div className="text-[10px] text-slate-400">Uploaded Specs</div>
        </div>
      </div>

      {/* Main Specifications Card */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <h2 className="text-sm font-bold text-slate-100 flex items-center space-x-2 border-b border-slate-800 pb-2">
            <Cpu className="w-4 h-4 text-emerald-400" />
            <span>Hardware Architecture Specifications</span>
          </h2>

          <div className="space-y-2 text-xs font-mono">
            <div className="flex justify-between py-1 border-b border-slate-800/60">
              <span className="text-slate-400">Main Controller (MCU)</span>
              <span className="text-slate-100 font-semibold">{project.mainController}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800/60">
              <span className="text-slate-400">Primary Power Source</span>
              <span className="text-slate-100 font-semibold">{project.powerSource}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800/60">
              <span className="text-slate-400">Active Interfaces</span>
              <span className="text-slate-100">{project.interfaces.join(', ')}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800/60">
              <span className="text-slate-400">Design Status</span>
              <span className="text-emerald-400 font-semibold">{project.status}</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-400">Last Modified</span>
              <span className="text-slate-300">{new Date(project.updatedAt).toLocaleTimeString()}</span>
            </div>
          </div>
        </div>

        {/* AI Engineering Activity Log */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <h2 className="text-sm font-bold text-slate-100 flex items-center space-x-2 border-b border-slate-800 pb-2">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <span>AI Activity & Audit Trail</span>
          </h2>

          <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
            {project.aiLog.length === 0 ? (
              <div className="text-xs text-slate-500 italic py-4 text-center">No AI modifications recorded yet.</div>
            ) : (
              project.aiLog.map((log) => (
                <div key={log.id} className="p-2 bg-slate-950 border border-slate-800/80 rounded-lg text-xs space-y-0.5">
                  <div className="flex items-center justify-between text-[10px] font-mono text-slate-500">
                    <span className="text-emerald-400 font-semibold">{log.action}</span>
                    <span>{log.timestamp}</span>
                  </div>
                  <div className="text-slate-300 text-[11px]">{log.details}</div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
