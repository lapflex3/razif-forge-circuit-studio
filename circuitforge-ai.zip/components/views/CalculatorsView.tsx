'use client';

import React, { useState } from 'react';
import { Calculator, Zap, Thermometer, Battery, Activity, ArrowRight, Check } from 'lucide-react';
import { 
  calculateResistorDivider, 
  calculateLedResistor, 
  calculateOhmsLaw, 
  calculateRcFilter, 
  calculateBatteryRuntime,
  calculateLdoThermal 
} from '@/lib/eda/calculators';
import { ProjectData } from '@/lib/types/eda';

interface CalculatorsViewProps {
  project: ProjectData;
  onUpdateProject: (p: ProjectData) => void;
}

export function CalculatorsView({ project, onUpdateProject }: CalculatorsViewProps) {
  const [activeTab, setActiveTab] = useState<'divider' | 'led' | 'ohms' | 'rc' | 'battery' | 'ldo'>('divider');

  // Resistor Divider State
  const [vIn, setVIn] = useState(5.0);
  const [r1, setR1] = useState(10000);
  const [r2, setR2] = useState(10000);

  // LED Resistor State
  const [ledVin, setLedVin] = useState(5.0);
  const [ledVf, setLedVf] = useState(2.0);
  const [ledIfMa, setLedIfMa] = useState(20);

  // Ohm's Law State
  const [ohmV, setOhmV] = useState(3.3);
  const [ohmI, setOhmI] = useState(100); // mA

  // RC Filter State
  const [rcR, setRcR] = useState(10000); // 10k
  const [rcC, setRcC] = useState(0.1); // 0.1uF

  // Battery Runtime State
  const [batVoltage, setBatVoltage] = useState(3.7);
  const [batAh, setBatAh] = useState(2.5); // 2500mAh
  const [deviceWatts, setDeviceWatts] = useState(1.2);

  // LDO Thermal State
  const [ldoVin, setLdoVin] = useState(5.0);
  const [ldoVout, setLdoVout] = useState(3.3);
  const [ldoCurrentMa, setLdoCurrentMa] = useState(300);

  // Outputs
  const dividerRes = calculateResistorDivider(vIn, r1, r2);
  const ledRes = calculateLedResistor(ledVin, ledVf, ledIfMa);
  const ohmRes = calculateOhmsLaw(ohmV, ohmI);
  const rcRes = calculateRcFilter(rcR, rcC);
  const batRes = calculateBatteryRuntime(batVoltage, batAh, deviceWatts);
  const ldoRes = calculateLdoThermal(ldoVin, ldoVout, ldoCurrentMa);

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-xl">
        <div className="space-y-1">
          <div className="flex items-center space-x-2 text-xs font-mono font-semibold text-emerald-400 uppercase">
            <Calculator className="w-4 h-4" />
            <span>Interactive Engineering Math Calculators</span>
          </div>
          <h1 className="text-xl font-bold text-slate-100">EDA Design Calculators</h1>
          <p className="text-xs text-slate-400">
            Real-time electronics equations for component selection, power dissipation, battery life, and signal filters.
          </p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center space-x-1 border-b border-slate-800 overflow-x-auto pb-1 scrollbar-none">
        {[
          { id: 'divider', label: 'Resistor Divider' },
          { id: 'led', label: 'LED Resistor' },
          { id: 'ohms', label: "Ohm's Law & Power" },
          { id: 'rc', label: 'RC Filter Cutoff' },
          { id: 'battery', label: 'Battery Runtime' },
          { id: 'ldo', label: 'LDO Thermal Loss' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-4 py-2 rounded-t-lg text-xs font-semibold transition-colors shrink-0 ${
              activeTab === tab.id
                ? 'bg-slate-900 text-emerald-400 border-t-2 border-emerald-500'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/40'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Resistor Divider View */}
      {activeTab === 'divider' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-slate-900 border border-slate-800 rounded-xl p-6">
          <div className="space-y-4">
            <h2 className="text-sm font-bold text-slate-100">Voltage Divider Parameters</h2>

            <div>
              <label className="block text-xs text-slate-400 mb-1">Input Voltage Vin (V)</label>
              <input
                type="number"
                step="0.1"
                value={vIn}
                onChange={(e) => setVIn(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-100 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">Top Resistor R1 (Ω)</label>
              <input
                type="number"
                value={r1}
                onChange={(e) => setR1(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-100 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">Bottom Resistor R2 (Ω)</label>
              <input
                type="number"
                value={r2}
                onChange={(e) => setR2(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-100 font-mono"
              />
            </div>
          </div>

          <div className="bg-slate-950 border border-slate-800 rounded-xl p-5 space-y-4 flex flex-col justify-between">
            <div>
              <div className="text-xs font-mono text-emerald-400 font-semibold mb-2 uppercase">Calculation Results</div>
              <div className="space-y-2 font-mono text-xs">
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Output Voltage (Vout)</span>
                  <span className="text-emerald-400 font-bold text-base">{dividerRes.vout.toFixed(3)} V</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Divider Current (I)</span>
                  <span className="text-slate-200">{dividerRes.currentMa.toFixed(3)} mA</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Total Power Dissipation</span>
                  <span className="text-slate-200">{dividerRes.powerMw.toFixed(2)} mW</span>
                </div>
              </div>
            </div>

            <div className="text-[11px] text-slate-500 font-mono bg-slate-900 p-2.5 rounded border border-slate-800">
              Formula: Vout = Vin × (R2 / (R1 + R2))
            </div>
          </div>
        </div>
      )}

      {/* LED Resistor View */}
      {activeTab === 'led' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-slate-900 border border-slate-800 rounded-xl p-6">
          <div className="space-y-4">
            <h2 className="text-sm font-bold text-slate-100">LED Current Limiting Specs</h2>

            <div>
              <label className="block text-xs text-slate-400 mb-1">Supply Voltage (V)</label>
              <input
                type="number"
                step="0.1"
                value={ledVin}
                onChange={(e) => setLedVin(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-100 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">LED Forward Voltage Vf (V)</label>
              <input
                type="number"
                step="0.1"
                value={ledVf}
                onChange={(e) => setLedVf(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-100 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">Desired Forward Current If (mA)</label>
              <input
                type="number"
                value={ledIfMa}
                onChange={(e) => setLedIfMa(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-100 font-mono"
              />
            </div>
          </div>

          <div className="bg-slate-950 border border-slate-800 rounded-xl p-5 space-y-4 flex flex-col justify-between">
            <div>
              <div className="text-xs font-mono text-emerald-400 font-semibold mb-2 uppercase">Calculation Results</div>
              <div className="space-y-2 font-mono text-xs">
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Required Resistor (Exact)</span>
                  <span className="text-emerald-400 font-bold text-base">{ledRes.resistorOhms.toFixed(1)} Ω</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Standard E24 Nearest Resistor</span>
                  <span className="text-cyan-400 font-bold">{ledRes.standardE24} Ω</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Resistor Power Dissipation</span>
                  <span className="text-slate-200">{ledRes.powerMw.toFixed(1)} mW</span>
                </div>
              </div>
            </div>

            <div className="text-[11px] text-slate-500 font-mono bg-slate-900 p-2.5 rounded border border-slate-800">
              Formula: R = (Vin - Vf) / If
            </div>
          </div>
        </div>
      )}

      {/* Battery Runtime View */}
      {activeTab === 'battery' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-slate-900 border border-slate-800 rounded-xl p-6">
          <div className="space-y-4">
            <h2 className="text-sm font-bold text-slate-100">Battery Specs & System Power</h2>

            <div>
              <label className="block text-xs text-slate-400 mb-1">Nominal Battery Voltage (V)</label>
              <input
                type="number"
                step="0.1"
                value={batVoltage}
                onChange={(e) => setBatVoltage(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-100 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">Battery Capacity (Ah / Amp-Hours)</label>
              <input
                type="number"
                step="0.1"
                value={batAh}
                onChange={(e) => setBatAh(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-100 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">Total Device Power Draw (Watts)</label>
              <input
                type="number"
                step="0.1"
                value={deviceWatts}
                onChange={(e) => setDeviceWatts(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-100 font-mono"
              />
            </div>
          </div>

          <div className="bg-slate-950 border border-slate-800 rounded-xl p-5 space-y-4 flex flex-col justify-between">
            <div>
              <div className="text-xs font-mono text-emerald-400 font-semibold mb-2 uppercase">Runtime Estimate</div>
              <div className="space-y-2 font-mono text-xs">
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Battery Energy</span>
                  <span className="text-slate-200">{batRes.wattHours.toFixed(2)} Wh</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Estimated Continuous Hours</span>
                  <span className="text-emerald-400 font-bold text-base">{batRes.hours.toFixed(1)} Hours</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Estimated Continuous Days</span>
                  <span className="text-cyan-400 font-bold">{batRes.days.toFixed(2)} Days</span>
                </div>
              </div>
            </div>

            <div className="text-[11px] text-slate-500 font-mono bg-slate-900 p-2.5 rounded border border-slate-800">
              Formula: Hours = (Capacity_Ah × Voltage) / Power_Watts
            </div>
          </div>
        </div>
      )}

      {/* LDO Thermal Loss View */}
      {activeTab === 'ldo' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-slate-900 border border-slate-800 rounded-xl p-6">
          <div className="space-y-4">
            <h2 className="text-sm font-bold text-slate-100 font-mono">LDO Thermal Loss Calculator</h2>

            <div>
              <label className="block text-xs text-slate-400 mb-1">LDO Input Voltage Vin (V)</label>
              <input
                type="number"
                step="0.1"
                value={ldoVin}
                onChange={(e) => setLdoVin(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-100 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">LDO Output Voltage Vout (V)</label>
              <input
                type="number"
                step="0.1"
                value={ldoVout}
                onChange={(e) => setLdoVout(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-100 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">Load Current Iload (mA)</label>
              <input
                type="number"
                value={ldoCurrentMa}
                onChange={(e) => setLdoCurrentMa(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-100 font-mono"
              />
            </div>
          </div>

          <div className="bg-slate-950 border border-slate-800 rounded-xl p-5 space-y-4 flex flex-col justify-between">
            <div>
              <div className="text-xs font-mono text-emerald-400 font-semibold mb-2 uppercase">Thermal Loss Results</div>
              <div className="space-y-2 font-mono text-xs">
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Power Loss / Heat</span>
                  <span className={`font-bold text-base ${ldoRes.isHot ? 'text-amber-400' : 'text-emerald-400'}`}>
                    {ldoRes.powerLossMw.toFixed(0)} mW ({(ldoRes.powerLossMw/1000).toFixed(2)} W)
                  </span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Thermal Temp Rise (SOT-223)</span>
                  <span className="text-slate-200">+{ldoRes.estimatedTempRiseC.toFixed(1)} °C</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Thermal Recommendation</span>
                  <span className="text-slate-300 text-[11px] text-right">{ldoRes.recommendation}</span>
                </div>
              </div>
            </div>

            <div className="text-[11px] text-slate-500 font-mono bg-slate-900 p-2.5 rounded border border-slate-800">
              Formula: P_loss = (Vin - Vout) × Iload
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
