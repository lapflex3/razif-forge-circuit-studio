'use client';

import React, { useState } from 'react';
import { Table, Search, Download, FileCode2, ExternalLink, Cpu, ShoppingBag } from 'lucide-react';
import { ProjectData } from '@/lib/types/eda';

interface BOMViewProps {
  project: ProjectData;
}

export function BOMView({ project }: BOMViewProps) {
  const [searchQuery, setSearchQuery] = useState('');

  const filtered = project.components.filter(
    (c) =>
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.ref.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.partNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (c.lcscPartNumber && c.lcscPartNumber.toLowerCase().includes(searchQuery.toLowerCase())) ||
      c.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleExportCSV = () => {
    let csv = 'Reference,Name,Category,Manufacturer,MPN,LCSC Part Number,Package,Value\n';
    project.components.forEach((c) => {
      csv += `"${c.ref}","${c.name}","${c.category}","${c.manufacturer}","${c.partNumber}","${c.lcscPartNumber || ''}","${c.package}","${c.value || ''}"\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${project.name.toLowerCase().replace(/[^a-z0-9]/g, '_')}_bom.csv`);
    document.body.appendChild(link);
    link.click();
    link.remove();
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-[#111112] border border-[#222] p-5 rounded-sm">
        <div className="space-y-1">
          <div className="flex items-center space-x-2 text-xs font-mono font-bold text-[#00FF00] uppercase">
            <Table className="w-4 h-4" />
            <span>Project Bill of Materials (BOM)</span>
            <span className="text-[9px] font-mono font-bold tracking-wider px-1.5 py-0.5 bg-[#1F1713] text-[#F27D26] border border-[#F27D26]/40 rounded-sm uppercase ml-2">
              RazifSoftwares
            </span>
          </div>
          <h1 className="text-xl font-bold text-white uppercase font-mono tracking-tight">Bill of Materials</h1>
          <p className="text-xs text-[#888]">
            Exportable component table with reference designators, MPNs, LCSC procurement codes, and packages.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <a
            href="https://www.lcsc.com/products"
            target="_blank"
            rel="noreferrer"
            className="px-3.5 py-2 bg-[#1F1713] hover:bg-[#2A1E17] text-[#F27D26] border border-[#F27D26]/60 font-mono font-bold text-xs uppercase rounded-sm flex items-center space-x-1.5 transition-colors"
          >
            <ShoppingBag className="w-4 h-4 text-[#F27D26]" />
            <span>LCSC Database</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>

          <button
            onClick={handleExportCSV}
            className="px-4 py-2 bg-[#00FF00] hover:bg-[#00DD00] text-[#0A0A0B] font-bold rounded-sm text-xs font-mono uppercase flex items-center space-x-1.5 transition-colors shadow-[0_0_10px_rgba(0,255,0,0.15)]"
          >
            <Download className="w-4 h-4" />
            <span>Export BOM CSV</span>
          </button>
        </div>
      </div>

      {/* Filter & Search */}
      <div className="bg-[#111112] p-3 rounded-sm border border-[#222] flex items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-[#666] absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search BOM by reference, part name, LCSC code..."
            className="w-full bg-[#1A1A1B] border border-[#333] rounded-sm pl-9 pr-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#00FF00]"
          />
        </div>

        <div className="text-xs font-mono text-[#888]">
          Total Items: <strong className="text-[#00FF00]">{filtered.length}</strong>
        </div>
      </div>

      {/* BOM Table */}
      <div className="bg-[#111112] border border-[#222] rounded-sm overflow-hidden shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#0A0A0B] border-b border-[#222] text-[#888] uppercase">
              <tr>
                <th className="p-3">Ref</th>
                <th className="p-3">Part Name</th>
                <th className="p-3">Category</th>
                <th className="p-3">Manufacturer</th>
                <th className="p-3">MPN</th>
                <th className="p-3">LCSC Part #</th>
                <th className="p-3">Package</th>
                <th className="p-3">Value / Specs</th>
                <th className="p-3 text-right">Procure / Datasheet</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#222] text-[#CCC]">
              {filtered.map((comp) => {
                const lcscCode = comp.lcscPartNumber || (comp.partNumber.startsWith('C') ? comp.partNumber : null);
                const lcscSearchUrl = lcscCode ? `https://www.lcsc.com/search?q=${lcscCode}` : `https://www.lcsc.com/search?q=${encodeURIComponent(comp.partNumber)}`;

                return (
                  <tr key={comp.id} className="hover:bg-[#1A1A1B] transition-colors">
                    <td className="p-3 font-bold text-[#F27D26]">{comp.ref}</td>
                    <td className="p-3 font-bold text-white">{comp.name}</td>
                    <td className="p-3 text-[#00FF00] uppercase text-[10px]">{comp.category}</td>
                    <td className="p-3 text-[#888]">{comp.manufacturer}</td>
                    <td className="p-3 text-[#BBB]">{comp.partNumber}</td>
                    <td className="p-3">
                      {lcscCode ? (
                        <a
                          href={lcscSearchUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="px-2 py-0.5 bg-[#1F1713] border border-[#F27D26]/60 text-[#F27D26] rounded-sm font-bold text-[10px] hover:underline inline-flex items-center space-x-1"
                        >
                          <span>{lcscCode}</span>
                          <ExternalLink className="w-2.5 h-2.5" />
                        </a>
                      ) : (
                        <span className="text-[#555]">-</span>
                      )}
                    </td>
                    <td className="p-3 text-[#888]">{comp.package}</td>
                    <td className="p-3 text-[#BBB]">{comp.value || '-'}</td>
                    <td className="p-3 text-right">
                      <div className="flex items-center justify-end space-x-2">
                        {comp.datasheetUrl && (
                          <a
                            href={comp.datasheetUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="text-[#00FF00] hover:underline inline-flex items-center space-x-1"
                          >
                            <span>PDF</span>
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        )}

                        <a
                          href={lcscSearchUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="text-[#F27D26] hover:underline inline-flex items-center space-x-1"
                          title="Order / Search on LCSC"
                        >
                          <span>LCSC</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
