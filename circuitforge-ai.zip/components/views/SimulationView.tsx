'use client';

import React, { useState } from 'react';
import { Activity, Play, RefreshCw, Zap, TrendingUp } from 'lucide-react';
import { ProjectData } from '@/lib/types/eda';

interface SimulationViewProps {
  project: ProjectData;
}

export function SimulationView({ project }: SimulationViewProps) {
  const [freqHz, setFreqHz] = useState(1000);
  const [voltagePeak, setVoltagePeak] = useState(3.3);
  const [resistance, setResistance] = useState(1000);
  const [capacitanceUf, setCapacitanceUf] = useState(1.0);
  const [isRunning, setIsRunning] = useState(false);

  // Generate 50 points for simulation waveform plot
  const points: { t: number; vIn: number; vOut: number }[] = [];
  const dt = (1 / freqHz) / 25; // time step for 2 periods
  const rc = resistance * (capacitanceUf * 1e-6);

  for (let i = 0; i < 50; i++) {
    const t = i * dt;
    const vIn = voltagePeak * Math.sin(2 * Math.PI * freqHz * t);
    // RC lowpass transfer magnitude: H = 1 / sqrt(1 + (w*RC)^2)
    const omega = 2 * Math.PI * freqHz;
    const gain = 1 / Math.sqrt(1 + Math.pow(omega * rc, 2));
    const phaseShift = Math.atan(-omega * rc);
    const vOut = voltagePeak * gain * Math.sin(2 * Math.PI * freqHz * t + phaseShift);

    points.push({ t, vIn, vOut });
  }

  const handleRunSimulation = () => {
    setIsRunning(true);
    setTimeout(() => setIsRunning(false), 800);
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-xl">
        <div className="space-y-1">
          <div className="flex items-center space-x-2 text-xs font-mono font-semibold text-cyan-400 uppercase">
            <Activity className="w-4 h-4" />
            <span>Integrated SPICE Analog Circuit Simulator</span>
          </div>
          <h1 className="text-xl font-bold text-slate-100">SPICE Waveform Simulator</h1>
          <p className="text-xs text-slate-400">
            Simulate transient time-domain signal responses, filter cutoff attenuation, and voltage waveforms.
          </p>
        </div>

        <button
          onClick={handleRunSimulation}
          disabled={isRunning}
          className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 disabled:bg-slate-800 text-slate-950 font-bold rounded-lg text-xs flex items-center space-x-1.5 transition-colors shadow-lg"
        >
          <Play className="w-4 h-4 fill-current" />
          <span>{isRunning ? 'Simulating...' : 'Run Transient Simulation'}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Controls */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <h2 className="text-sm font-bold text-slate-100 font-mono uppercase text-emerald-400">
            Signal Parameters
          </h2>

          <div>
            <label className="block text-xs text-slate-400 mb-1">Signal Frequency (Hz)</label>
            <input
              type="number"
              value={freqHz}
              onChange={(e) => setFreqHz(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-100 font-mono"
            />
          </div>

          <div>
            <label className="block text-xs text-slate-400 mb-1">Peak Voltage Vin (V)</label>
            <input
              type="number"
              step="0.1"
              value={voltagePeak}
              onChange={(e) => setVoltagePeak(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-100 font-mono"
            />
          </div>

          <div>
            <label className="block text-xs text-slate-400 mb-1">Filter Resistance R (Ω)</label>
            <input
              type="number"
              value={resistance}
              onChange={(e) => setResistance(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-100 font-mono"
            />
          </div>

          <div>
            <label className="block text-xs text-slate-400 mb-1">Filter Capacitance C (µF)</label>
            <input
              type="number"
              step="0.1"
              value={capacitanceUf}
              onChange={(e) => setCapacitanceUf(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-100 font-mono"
            />
          </div>
        </div>

        {/* Waveform Plot */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-bold text-slate-100">Oscilloscope Transient Plot (Vin vs Vout)</span>
            <div className="flex items-center space-x-3 text-xs font-mono">
              <span className="flex items-center space-x-1 text-cyan-400">
                <span className="w-2.5 h-2.5 bg-cyan-400 rounded-full inline-block" />
                <span>Vin (Input)</span>
              </span>
              <span className="flex items-center space-x-1 text-emerald-400">
                <span className="w-2.5 h-2.5 bg-emerald-400 rounded-full inline-block" />
                <span>Vout (Filtered)</span>
              </span>
            </div>
          </div>

          {/* SVG Graph Canvas */}
          <div className="h-64 bg-slate-950 border border-slate-800 rounded-lg p-2 relative overflow-hidden flex items-center justify-center">
            <svg className="w-full h-full overflow-visible">
              {/* Gridlines */}
              <line x1="0" y1="50%" x2="100%" y2="50%" stroke="#1e293b" strokeDasharray="4,4" />
              <line x1="50%" y1="0" x2="50%" y2="100%" stroke="#1e293b" strokeDasharray="4,4" />

              {/* Vin Path */}
              <path
                d={points
                  .map((p, idx) => {
                    const x = (idx / (points.length - 1)) * 500;
                    const y = 100 - (p.vIn / (voltagePeak || 1)) * 80;
                    return `${idx === 0 ? 'M' : 'L'} ${x} ${y}`;
                  })
                  .join(' ')}
                fill="none"
                stroke="#38bdf8"
                strokeWidth="2"
              />

              {/* Vout Path */}
              <path
                d={points
                  .map((p, idx) => {
                    const x = (idx / (points.length - 1)) * 500;
                    const y = 100 - (p.vOut / (voltagePeak || 1)) * 80;
                    return `${idx === 0 ? 'M' : 'L'} ${x} ${y}`;
                  })
                  .join(' ')}
                fill="none"
                stroke="#10b981"
                strokeWidth="2.5"
              />
            </svg>
          </div>

          <div className="text-[11px] font-mono text-slate-400 bg-slate-950 p-2.5 rounded border border-slate-800 flex justify-between">
            <span>Cutoff Frequency fc: {(1 / (2 * Math.PI * resistance * capacitanceUf * 1e-6)).toFixed(1)} Hz</span>
            <span>RC Time Constant τ: {(resistance * capacitanceUf * 1e-3).toFixed(2)} ms</span>
          </div>
        </div>
      </div>
    </div>
  );
}
