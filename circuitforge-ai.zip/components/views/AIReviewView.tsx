'use client';

import React, { useState } from 'react';
import { ShieldCheck, ShieldAlert, AlertTriangle, CheckCircle2, Info, Sparkles, RefreshCw, Loader2 } from 'lucide-react';
import { ProjectData, ERCWarning } from '@/lib/types/eda';
import { runERC } from '@/lib/eda/ercEngine';
import { generateId } from '@/lib/utils/idGenerator';

interface AIReviewViewProps {
  project: ProjectData;
  onUpdateProject: (p: ProjectData) => void;
  onRunERC: () => void;
}

export function AIReviewView({ project, onUpdateProject, onRunERC }: AIReviewViewProps) {
  const [filterSeverity, setFilterSeverity] = useState<string>('ALL');
  const [isAuditing, setIsAuditing] = useState(false);

  const warnings = project.warnings || [];

  const filtered = warnings.filter((w) =>
    filterSeverity === 'ALL' ? true : w.severity === filterSeverity
  );

  const handleRunFullAudit = () => {
    setIsAuditing(true);
    setTimeout(() => {
      const freshWarnings = runERC(project);
      onUpdateProject({ ...project, warnings: freshWarnings });
      setIsAuditing(false);
    }, 1000);
  };

  const handleApplyFix = (warning: ERCWarning) => {
    let updated = { ...project };

    if (warning.code === 'ERC_UNCONNECTED_EN') {
      // Add pullup resistor
      const pullup = {
        id: generateId('comp_r_pullup'),
        ref: 'R_EN_PULLUP',
        name: '10k Pullup Resistor',
        manufacturer: 'Yageo',
        partNumber: 'RC0603FR-0710KL',
        category: 'resistor' as const,
        package: '0603',
        value: '10kΩ',
        description: 'Pullup for EN enable pin',
        symbolId: 'sym_res',
        pins: [],
      };
      updated.components = [...updated.components, pullup];
    }

    // Remove resolved warning
    updated.warnings = updated.warnings.filter((w) => w.id !== warning.id);
    onUpdateProject(updated);
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-xl">
        <div className="space-y-1">
          <div className="flex items-center space-x-2 text-xs font-mono font-semibold text-amber-400 uppercase">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Electrical Rules Check (ERC) & AI Audit</span>
          </div>
          <h1 className="text-xl font-bold text-slate-100">Design Verification & Safety Audit</h1>
          <p className="text-xs text-slate-400">
            Automated check for floating enable pins, missing decoupling capacitors, bus conflicts, and thermal dissipation limits.
          </p>
        </div>

        <button
          onClick={handleRunFullAudit}
          disabled={isAuditing}
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 text-slate-950 font-bold rounded-lg text-xs flex items-center space-x-1.5 transition-colors shadow-lg"
        >
          {isAuditing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
          <span>{isAuditing ? 'Auditing Design...' : 'Run Full AI Audit'}</span>
        </button>
      </div>

      {/* Filter severity tabs */}
      <div className="flex items-center space-x-2">
        {['ALL', 'CRITICAL', 'WARNING', 'INFO', 'PASS'].map((sev) => (
          <button
            key={sev}
            onClick={() => setFilterSeverity(sev)}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold transition-colors ${
              filterSeverity === sev
                ? 'bg-emerald-600 text-slate-950'
                : 'bg-slate-900 text-slate-400 hover:bg-slate-800 border border-slate-800'
            }`}
          >
            {sev}
          </button>
        ))}
      </div>

      {/* Warnings List */}
      <div className="space-y-3">
        {filtered.length === 0 ? (
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 text-center space-y-2">
            <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
            <h3 className="text-sm font-bold text-slate-100">No ERC Warnings Found</h3>
            <p className="text-xs text-slate-400">All electrical connection rules and decoupling constraints passed verification.</p>
          </div>
        ) : (
          filtered.map((w) => (
            <div
              key={w.id}
              className={`p-4 bg-slate-900 border rounded-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-md ${
                w.severity === 'CRITICAL'
                  ? 'border-rose-800/80 bg-rose-950/20'
                  : w.severity === 'WARNING'
                  ? 'border-amber-800/80 bg-amber-950/20'
                  : 'border-slate-800'
              }`}
            >
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold uppercase ${
                    w.severity === 'CRITICAL' ? 'bg-rose-950 text-rose-300 border border-rose-800' :
                    w.severity === 'WARNING' ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                    'bg-slate-800 text-slate-300'
                  }`}>
                    {w.severity}
                  </span>
                  <span className="text-xs font-mono text-slate-400">Rule ID: {w.code}</span>
                </div>

                <h3 className="text-sm font-bold text-slate-100">{w.message}</h3>
                <p className="text-xs text-slate-400 max-w-2xl">{w.recommendation}</p>
              </div>

              <button
                onClick={() => handleApplyFix(w)}
                className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold rounded-lg text-xs flex items-center space-x-1 shrink-0 transition-colors"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Auto-Fix with AI</span>
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
