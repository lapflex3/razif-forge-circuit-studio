'use client';

import React, { useState } from 'react';
import { FileText, Upload, Search, Bot, ExternalLink, Sparkles, Send, Check } from 'lucide-react';
import { ProjectData } from '@/lib/types/eda';

interface DocumentsViewProps {
  project: ProjectData;
  onUpdateProject: (p: ProjectData) => void;
}

export function DocumentsView({ project, onUpdateProject }: DocumentsViewProps) {
  const [question, setQuestion] = useState('');
  const [qaHistory, setQaHistory] = useState<{ q: string; a: string; time: string }[]>([
    {
      q: 'What is the absolute maximum supply voltage for ESP32-S3-WROOM-1?',
      a: 'According to the ESP32-S3 datasheet Section 5.1 (Absolute Maximum Ratings), the maximum power supply voltage VDD is 3.6V (recommended operating voltage range is 3.0V to 3.6V, typical 3.3V). Exceeding 3.6V will damage the internal silicon.',
      time: '10:15 AM',
    },
    {
      q: 'What are the default I2C pins for SX1262 LoRa module?',
      a: 'The SX1262 transceiver communicates primarily over SPI (NSS, SCK, MOSI, MISO) along with BUSY and DIO1 interrupt pins. It does not use I2C as its main interface.',
      time: '10:18 AM',
    },
  ]);
  const [isAsking, setIsAsking] = useState(false);

  const handleAskQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim() || isAsking) return;

    const userQ = question;
    setQuestion('');
    setIsAsking(true);

    setTimeout(() => {
      let answer = `Regarding "${userQ}": The component datasheets specify standard 3.3V logic levels with ±5% voltage tolerance. ESD protection on IO pins is rated for 2kV HBM.`;
      if (userQ.toLowerCase().includes('esp32')) {
        answer = `ESP32-S3 technical reference manual confirms GPIO pins operate at 3.3V. Pin 3 (EN) requires an external 10k pull-up resistor and 1uF delay capacitor for clean power-on reset.`;
      } else if (userQ.toLowerCase().includes('lora') || userQ.toLowerCase().includes('sx1262')) {
        answer = `SX1262 datasheet recommends placing a 10uH inductor and 100nF decoupling capacitors near the VBAT_RF power pin. Matched RF output impedance is 50 Ohms.`;
      }

      setQaHistory((prev) => [
        ...prev,
        {
          q: userQ,
          a: answer,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
      setIsAsking(false);
    }, 1000);
  };

  const handleUploadDocument = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const newDoc = {
      id: 'doc_' + Date.now(),
      name: file.name,
      type: (file.name.endsWith('.pdf') ? 'pdf' : 'txt') as 'pdf' | 'txt',
      size: (file.size / 1024).toFixed(1) + ' KB',
      uploadDate: new Date().toLocaleDateString(),
    };

    onUpdateProject({ ...project, documents: [...project.documents, newDoc] });
  };

  const handlePrintDocument = () => {
    window.print();
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6 relative">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-[#111112] border border-[#222] p-5 rounded-sm">
        <div className="space-y-1">
          <div className="flex items-center space-x-2 text-xs font-mono font-bold text-[#00FF00] uppercase">
            <FileText className="w-4 h-4" />
            <span>Datasheet AI Q&A Assistant</span>
            <span className="text-[9px] font-mono font-bold tracking-wider px-1.5 py-0.5 bg-[#1F1713] text-[#F27D26] border border-[#F27D26]/40 rounded-sm uppercase ml-2">
              RazifSoftwares Watermarked
            </span>
          </div>
          <h1 className="text-xl font-bold text-white uppercase font-mono tracking-tight">Datasheets & Technical Specs</h1>
          <p className="text-xs text-[#888]">
            Upload PDF datasheets, IC manuals, and ask AI questions about pinouts, register maps, or maximum operating ratings.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={handlePrintDocument}
            className="px-3 py-2 bg-[#1A1A1B] hover:bg-[#222] text-[#CCC] border border-[#333] font-bold rounded-sm text-xs font-mono uppercase flex items-center space-x-1.5 transition-colors"
          >
            <FileText className="w-4 h-4 text-[#F27D26]" />
            <span>Print Report</span>
          </button>

          <label className="px-4 py-2 bg-[#00FF00] hover:bg-[#00DD00] text-[#0A0A0B] font-bold rounded-sm text-xs font-mono uppercase flex items-center space-x-1.5 transition-colors cursor-pointer shadow-[0_0_10px_rgba(0,255,0,0.15)]">
            <Upload className="w-4 h-4" />
            <span>Upload Datasheet</span>
            <input type="file" accept=".pdf,.txt,.md" onChange={handleUploadDocument} className="hidden" />
          </label>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Uploaded Files list */}
        <div className="bg-[#111112] border border-[#222] rounded-sm p-5 space-y-4">
          <h2 className="text-xs font-bold text-[#00FF00] font-mono uppercase tracking-wider">
            Project Datasheets ({project.documents.length})
          </h2>

          <div className="space-y-2">
            {project.documents.length === 0 ? (
              <div className="text-xs text-[#666] font-mono italic py-6 text-center border border-dashed border-[#222] rounded-sm">
                No custom datasheets uploaded yet. Default component datasheets are loaded automatically.
              </div>
            ) : (
              project.documents.map((doc) => (
                <div key={doc.id} className="p-3 bg-[#1A1A1B] border border-[#333] rounded-sm flex items-center justify-between">
                  <div>
                    <div className="text-xs font-bold text-white">{doc.name}</div>
                    <div className="text-[10px] font-mono text-[#777]">{doc.size} • Uploaded {doc.uploadDate}</div>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-sm bg-[#131F15] text-[#00FF00] border border-[#00FF00]/40">
                    Indexed
                  </span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* AI QA Panel */}
        <div className="lg:col-span-2 bg-[#111112] border border-[#222] rounded-sm p-5 flex flex-col justify-between space-y-4">
          <div className="space-y-4">
            <div className="flex items-center space-x-2 border-b border-[#222] pb-2">
              <Bot className="w-4 h-4 text-[#00FF00]" />
              <h2 className="text-xs font-mono font-bold text-white uppercase tracking-wider">Datasheet AI Assistant</h2>
            </div>

            <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
              {qaHistory.map((item, idx) => (
                <div key={idx} className="space-y-1.5 bg-[#1A1A1B] p-3 rounded-sm border border-[#333]">
                  <div className="text-xs font-bold text-white flex items-center justify-between">
                    <span>Q: {item.q}</span>
                    <span className="text-[10px] font-mono text-[#666]">{item.time}</span>
                  </div>
                  <p className="text-xs text-[#CCC] leading-relaxed pl-2 border-l-2 border-[#00FF00]">
                    {item.a}
                  </p>
                </div>
              ))}
            </div>
          </div>

          <form onSubmit={handleAskQuestion} className="flex items-center space-x-2 pt-2 border-t border-[#222]">
            <input
              type="text"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="Ask a technical question about component datasheets or pinouts..."
              className="flex-1 bg-[#1A1A1B] border border-[#333] rounded-sm px-3 py-2 text-xs text-white focus:outline-none focus:border-[#00FF00]"
            />
            <button
              type="submit"
              disabled={!question.trim() || isAsking}
              className="px-4 py-2 bg-[#00FF00] hover:bg-[#00DD00] text-[#0A0A0B] font-bold font-mono uppercase rounded-sm text-xs flex items-center space-x-1 transition-colors"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Ask AI</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
