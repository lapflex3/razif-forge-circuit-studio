'use client';

import React, { useState } from 'react';
import { Network, Plus, Trash2, Cpu, Zap, Shield } from 'lucide-react';
import { ProjectData, Net } from '@/lib/types/eda';

interface NetlistViewProps {
  project: ProjectData;
  onUpdateProject: (p: ProjectData) => void;
}

export function NetlistView({ project, onUpdateProject }: NetlistViewProps) {
  const [newNetName, setNewNetName] = useState('GPIO_SENS_INT');
  const [newNetType, setNewNetType] = useState<Net['type']>('signal');
  const [showAddModal, setShowAddModal] = useState(false);

  const handleAddNet = () => {
    if (!newNetName.trim()) return;
    const newNet: Net = {
      id: 'net_' + Date.now(),
      name: newNetName.toUpperCase(),
      type: newNetType,
      pins: [],
    };

    onUpdateProject({ ...project, nets: [...project.nets, newNet] });
    setShowAddModal(false);
  };

  const handleDeleteNet = (netId: string) => {
    const updatedNets = project.nets.filter((n) => n.id !== netId);
    onUpdateProject({ ...project, nets: updatedNets });
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-xl">
        <div className="space-y-1">
          <div className="flex items-center space-x-2 text-xs font-mono font-semibold text-emerald-400 uppercase">
            <Network className="w-4 h-4" />
            <span>Circuit Netlist & Signal Connections Inspector</span>
          </div>
          <h1 className="text-xl font-bold text-slate-100">Project Netlist</h1>
          <p className="text-xs text-slate-400">
            Internal topological model listing all electrical nets, power rails, signal traces, and pin nodes.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold rounded-lg text-xs flex items-center space-x-1.5 transition-colors shadow-lg"
        >
          <Plus className="w-4 h-4" />
          <span>Add Electrical Net</span>
        </button>
      </div>

      {/* Net List Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-950 border-b border-slate-800 text-slate-400 uppercase">
              <tr>
                <th className="p-3">Net Name</th>
                <th className="p-3">Net Type</th>
                <th className="p-3">Voltage Rail</th>
                <th className="p-3">Connected Pin Nodes</th>
                <th className="p-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {project.nets.map((net) => (
                <tr key={net.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="p-3 font-bold text-emerald-400">{net.name}</td>
                  <td className="p-3">
                    <span className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold ${
                      net.type === 'power' ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                      net.type === 'ground' ? 'bg-slate-800 text-slate-300' :
                      'bg-cyan-950 text-cyan-300 border border-cyan-800'
                    }`}>
                      {net.type}
                    </span>
                  </td>
                  <td className="p-3 text-slate-400">{net.voltage || 'N/A'}</td>
                  <td className="p-3">
                    <div className="flex flex-wrap gap-1">
                      {net.pins.length === 0 ? (
                        <span className="text-slate-500 italic">No pins wired</span>
                      ) : (
                        net.pins.map((p, idx) => {
                          const comp = project.components.find((c) => c.id === p.componentId);
                          return (
                            <span key={idx} className="bg-slate-950 border border-slate-800 px-2 py-0.5 rounded text-[10px] text-slate-300">
                              {comp?.ref || 'U?'}.P{p.pinNumber} ({p.pinName})
                            </span>
                          );
                        })
                      )}
                    </div>
                  </td>
                  <td className="p-3 text-right">
                    <button
                      onClick={() => handleDeleteNet(net.id)}
                      className="text-slate-500 hover:text-rose-400 p-1 rounded hover:bg-slate-800 transition-colors"
                      title="Delete Net"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 max-w-md w-full space-y-4">
            <h3 className="text-sm font-bold text-slate-100">Add New Circuit Net</h3>

            <div>
              <label className="block text-xs text-slate-400 mb-1">Net Name</label>
              <input
                type="text"
                value={newNetName}
                onChange={(e) => setNewNetName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">Net Type</label>
              <select
                value={newNetType}
                onChange={(e) => setNewNetType(e.target.value as Net['type'])}
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-emerald-500"
              >
                <option value="signal">Signal Trace</option>
                <option value="power">Power Rail</option>
                <option value="ground">Ground (GND)</option>
                <option value="bus">Data Bus</option>
              </select>
            </div>

            <div className="flex items-center justify-end space-x-2 pt-2 border-t border-slate-800">
              <button
                onClick={() => setShowAddModal(false)}
                className="px-3 py-1.5 bg-slate-800 text-slate-300 rounded text-xs"
              >
                Cancel
              </button>
              <button
                onClick={handleAddNet}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold rounded text-xs"
              >
                Add Net
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
