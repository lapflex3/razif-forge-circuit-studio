'use client';

import React from 'react';
import { 
  FolderKanban, 
  Plus, 
  Upload, 
  Clock, 
  Cpu, 
  Network, 
  CheckCircle2, 
  AlertCircle,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { ProjectData } from '@/lib/types/eda';
import { OTHER_EXAMPLE_PROJECTS, DEMO_PROJECT_ESP32_LORA } from '@/lib/sampleData';

interface ProjectsViewProps {
  currentProject: ProjectData;
  onSelectProject: (project: ProjectData) => void;
  onOpenWizard: () => void;
}

export function ProjectsView({
  currentProject,
  onSelectProject,
  onOpenWizard,
}: ProjectsViewProps) {
  const allExamples = [DEMO_PROJECT_ESP32_LORA, ...OTHER_EXAMPLE_PROJECTS];

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-8">
      {/* Header Banner */}
      <div className="flex items-center justify-between bg-gradient-to-r from-slate-900 via-slate-900 to-slate-950 p-6 rounded-2xl border border-slate-800 shadow-xl">
        <div className="space-y-2">
          <div className="flex items-center space-x-2 text-emerald-400 font-mono text-xs font-semibold uppercase">
            <Sparkles className="w-4 h-4" />
            <span>AI-Assisted EDA Workspace</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-100">Project Dashboard</h1>
          <p className="text-xs text-slate-400 max-w-xl">
            Create, load, or manage electronic engineering designs. CircuitForge AI assists with block architecture, component specs, power calculations, and ERC checks.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={onOpenWizard}
            className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold px-4 py-2.5 rounded-xl text-xs flex items-center space-x-2 transition-all shadow-lg hover:shadow-emerald-500/20"
          >
            <Plus className="w-4 h-4" />
            <span>New Project Wizard</span>
          </button>
        </div>
      </div>

      {/* Active Project Card */}
      <div className="space-y-3">
        <div className="text-xs font-mono font-semibold uppercase text-slate-400 flex items-center space-x-2">
          <Clock className="w-4 h-4 text-emerald-400" />
          <span>Currently Loaded Active Project</span>
        </div>

        <div className="bg-slate-900 border-2 border-emerald-500/60 rounded-xl p-5 flex items-center justify-between shadow-xl">
          <div className="space-y-1.5">
            <div className="flex items-center space-x-3">
              <h2 className="text-lg font-bold text-slate-100">{currentProject.name}</h2>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 border border-emerald-800 text-emerald-300">
                {currentProject.status}
              </span>
            </div>
            <p className="text-xs text-slate-400 max-w-2xl">{currentProject.description}</p>

            <div className="flex items-center space-x-4 text-xs font-mono text-slate-400 pt-2">
              <span className="flex items-center space-x-1">
                <Cpu className="w-3.5 h-3.5 text-slate-500" />
                <span>MCU: {currentProject.mainController}</span>
              </span>
              <span>•</span>
              <span>Power: {currentProject.powerSource}</span>
              <span>•</span>
              <span>Components: {currentProject.components.length}</span>
              <span>•</span>
              <span>Nets: {currentProject.nets.length}</span>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <span className="text-xs text-emerald-400 font-semibold px-3 py-1.5 bg-emerald-950/60 border border-emerald-800 rounded-lg">
              Active in Workspace
            </span>
          </div>
        </div>
      </div>

      {/* Example Projects Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="text-xs font-mono font-semibold uppercase text-slate-400 flex items-center space-x-2">
            <FolderKanban className="w-4 h-4 text-cyan-400" />
            <span>Example Hardware Architectures</span>
          </div>
          <span className="text-xs text-slate-500">Click any project to load into workspace</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {allExamples.map((proj) => {
            const isCurrent = proj.id === currentProject.id;
            return (
              <div
                key={proj.id}
                onClick={() => onSelectProject(proj as ProjectData)}
                className={`bg-slate-900 border rounded-xl p-4 cursor-pointer transition-all hover:border-emerald-500/60 hover:shadow-lg group ${
                  isCurrent ? 'border-emerald-500/80 bg-slate-900/90' : 'border-slate-800'
                }`}
              >
                <div className="flex items-start justify-between mb-2">
                  <h3 className="text-sm font-bold text-slate-100 group-hover:text-emerald-400 transition-colors">
                    {proj.name}
                  </h3>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-slate-400">
                    {proj.status}
                  </span>
                </div>

                <p className="text-xs text-slate-400 line-clamp-2 mb-3 min-h-[2.25rem]">
                  {proj.description}
                </p>

                <div className="flex items-center justify-between text-[11px] font-mono text-slate-500 pt-2 border-t border-slate-800/80">
                  <div className="flex items-center space-x-1 text-slate-300">
                    <Cpu className="w-3.5 h-3.5 text-slate-500" />
                    <span>{proj.mainController}</span>
                  </div>
                  <div className="flex items-center space-x-1 text-emerald-400 font-medium">
                    <span>Load</span>
                    <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
