'use client';

import React, { useState } from 'react';
import { 
  Cpu, 
  Search, 
  Plus, 
  ExternalLink, 
  Check, 
  Layers, 
  Tag,
  FileText,
  ShoppingBag,
  Zap,
  Globe
} from 'lucide-react';
import { ProjectData, ComponentItem } from '@/lib/types/eda';
import { SAMPLE_COMPONENTS } from '@/lib/sampleData';
import { generateId, generateCoordinates } from '@/lib/utils/idGenerator';

interface ComponentsViewProps {
  project: ProjectData;
  onUpdateProject: (p: ProjectData) => void;
}

export function ComponentsView({ project, onUpdateProject }: ComponentsViewProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);

  // New Custom Component Form State
  const [newName, setNewName] = useState('STM32F401MCU');
  const [newRef, setNewRef] = useState('U3');
  const [newCategory, setNewCategory] = useState<ComponentItem['category']>('MCU');
  const [newMfg, setNewMfg] = useState('STMicroelectronics');
  const [newMpn, setNewMpn] = useState('STM32F401RET6');
  const [newLcsc, setNewLcsc] = useState('C52382');
  const [newPackage, setNewPackage] = useState('LQFP-64');
  const [newValue, setNewValue] = useState('84MHz 512KB Flash');
  const [newDesc, setNewDesc] = useState('High performance ARM Cortex-M4 MCU');

  const categories = [
    'ALL', 'MCU', 'regulator', 'capacitor', 'resistor', 'diode', 'MOSFET', 
    'transistor', 'connector', 'sensor', 'display', 'battery', 'charger', 
    'protection', 'communication', 'memory', 'oscillator', 'crystal', 'LED'
  ];

  const libraryComponents = [...SAMPLE_COMPONENTS, ...project.components];

  const filteredComponents = libraryComponents.filter((comp) => {
    const matchesCategory = selectedCategory === 'ALL' || comp.category === selectedCategory;
    const q = searchQuery.toLowerCase().trim();
    const matchesSearch =
      !q ||
      comp.name.toLowerCase().includes(q) ||
      comp.partNumber.toLowerCase().includes(q) ||
      (comp.lcscPartNumber && comp.lcscPartNumber.toLowerCase().includes(q)) ||
      comp.manufacturer.toLowerCase().includes(q) ||
      comp.package.toLowerCase().includes(q) ||
      comp.description.toLowerCase().includes(q);
    return matchesCategory && matchesSearch;
  });

  const handleAddComponentToProject = (comp: ComponentItem) => {
    const refPrefix = comp.category === 'MCU' ? 'U' : comp.category === 'resistor' ? 'R' : comp.category === 'capacitor' ? 'C' : 'U';
    const nextNum = project.components.filter((c) => c.category === comp.category).length + 1;
    const coords = generateCoordinates(200, 150);

    const newInst: ComponentItem = {
      ...comp,
      id: generateId('comp_inst'),
      ref: `${refPrefix}${nextNum}`,
      x: coords.x,
      y: coords.y,
    };

    onUpdateProject({ ...project, components: [...project.components, newInst] });
  };

  const handleCreateCustomComponent = () => {
    if (!newName.trim()) return;

    const newCustom: ComponentItem = {
      id: 'custom_' + Date.now(),
      ref: newRef || 'U_CUSTOM',
      name: newName,
      manufacturer: newMfg,
      partNumber: newMpn,
      lcscPartNumber: newLcsc.trim() || undefined,
      category: newCategory,
      package: newPackage,
      value: newValue,
      description: newDesc,
      symbolId: 'sym_custom',
      pins: [
        { id: 'cp1', number: '1', name: 'VCC', type: 'power_in' },
        { id: 'cp2', number: '2', name: 'GND', type: 'ground' },
        { id: 'cp3', number: '3', name: 'IO1', type: 'bidirectional' },
        { id: 'cp4', number: '4', name: 'IO2', type: 'bidirectional' },
      ],
    };

    onUpdateProject({ ...project, components: [...project.components, newCustom] });
    setShowAddModal(false);
  };

  const handleOpenLcscSearch = () => {
    const query = searchQuery.trim() || 'ESP32';
    window.open(`https://www.lcsc.com/search?q=${encodeURIComponent(query)}`, '_blank');
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-[#111112] border border-[#222] p-5 rounded-sm">
        <div className="space-y-1">
          <div className="flex items-center space-x-2 text-xs font-mono font-bold text-[#00FF00] uppercase">
            <Cpu className="w-4 h-4" />
            <span>LCSC & EDA Electronic Component Library</span>
            <span className="text-[9px] font-mono font-bold tracking-wider px-1.5 py-0.5 bg-[#1F1713] text-[#F27D26] border border-[#F27D26]/40 rounded-sm uppercase ml-2">
              RazifSoftwares
            </span>
          </div>
          <h1 className="text-xl font-bold text-white uppercase font-mono tracking-tight">Component Database</h1>
          <p className="text-xs text-[#888]">
            Browse verified MCU cores, LCSC parts, power regulators, sensors, passive components, and connectors.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          {/* Link to LCSC Component Database */}
          <a
            href="https://www.lcsc.com/products"
            target="_blank"
            rel="noreferrer"
            className="px-3.5 py-2 bg-[#1F1713] hover:bg-[#2A1E17] text-[#F27D26] border border-[#F27D26]/60 font-mono font-bold text-xs uppercase rounded-sm flex items-center space-x-1.5 transition-colors"
            title="Open official LCSC Electronics Component Store Database"
          >
            <ShoppingBag className="w-4 h-4 text-[#F27D26]" />
            <span>LCSC Database</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>

          <button
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2 bg-[#00FF00] hover:bg-[#00DD00] text-[#0A0A0B] font-bold rounded-sm text-xs font-mono uppercase flex items-center space-x-1.5 transition-colors shadow-[0_0_10px_rgba(0,255,0,0.15)]"
          >
            <Plus className="w-4 h-4" />
            <span>Add Custom Part</span>
          </button>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 bg-[#111112] p-3 rounded-sm border border-[#222]">
        <div className="relative flex-1 flex items-center space-x-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-[#666] absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by MPN, LCSC Part # (e.g. C2913202), component name, package..."
              className="w-full bg-[#1A1A1B] border border-[#333] rounded-sm pl-9 pr-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#00FF00]"
            />
          </div>

          <button
            onClick={handleOpenLcscSearch}
            className="px-3 py-1.5 bg-[#1F1713] hover:bg-[#2A1E17] text-[#F27D26] border border-[#F27D26]/60 rounded-sm text-xs font-mono font-bold uppercase shrink-0 flex items-center space-x-1"
            title="Direct Search on LCSC.com"
          >
            <Globe className="w-3.5 h-3.5" />
            <span>LCSC Search</span>
          </button>
        </div>

        {/* Category Pills */}
        <div className="flex items-center space-x-1 overflow-x-auto pb-1 md:pb-0 scrollbar-none">
          {categories.slice(0, 9).map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-2.5 py-1 rounded-sm text-xs font-mono font-bold transition-colors shrink-0 uppercase ${
                selectedCategory === cat
                  ? 'bg-[#00FF00] text-[#0A0A0B]'
                  : 'bg-[#1A1A1B] text-[#888] hover:text-white hover:bg-[#222]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Grid of Components */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredComponents.map((comp, idx) => {
          const lcscCode = comp.lcscPartNumber || (comp.partNumber.startsWith('C') ? comp.partNumber : null);
          const lcscUrl = lcscCode ? `https://www.lcsc.com/search?q=${lcscCode}` : `https://www.lcsc.com/search?q=${encodeURIComponent(comp.partNumber)}`;

          return (
            <div
              key={comp.id + '_' + idx}
              className="bg-[#111112] border border-[#222] rounded-sm p-4 flex flex-col justify-between space-y-3 hover:border-[#00FF00]/50 transition-all shadow-xl group"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-sm bg-[#1A1A1B] border border-[#333] text-[#00FF00] font-bold uppercase">
                    {comp.category}
                  </span>
                  
                  {/* LCSC Badge */}
                  {lcscCode ? (
                    <a
                      href={lcscUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="text-[10px] font-mono px-2 py-0.5 rounded-sm bg-[#1F1713] border border-[#F27D26]/60 text-[#F27D26] font-bold hover:underline flex items-center space-x-1"
                      title="View product details on LCSC Electronics"
                    >
                      <span>LCSC: {lcscCode}</span>
                      <ExternalLink className="w-2.5 h-2.5" />
                    </a>
                  ) : (
                    <span className="text-xs font-mono text-[#666]">{comp.package}</span>
                  )}
                </div>

                <h3 className="text-sm font-bold text-white group-hover:text-[#00FF00] transition-colors">{comp.name}</h3>
                <div className="text-[11px] font-mono text-[#888]">
                  {comp.manufacturer} • <span className="text-[#CCC]">{comp.partNumber}</span>
                </div>
                <p className="text-xs text-[#AAA] line-clamp-2">{comp.description}</p>
              </div>

              {/* Pins preview */}
              {comp.pins && comp.pins.length > 0 && (
                <div className="bg-[#1A1A1B] p-2 rounded-sm border border-[#222] space-y-1">
                  <div className="text-[10px] font-mono text-[#666] uppercase font-bold">
                    Pin Configuration ({comp.pins.length} Pins)
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {comp.pins.slice(0, 6).map((pin) => (
                      <span key={pin.id} className="text-[10px] font-mono px-1.5 py-0.5 bg-[#111112] text-[#CCC] rounded-sm border border-[#333]">
                        P{pin.number}:{pin.name}
                      </span>
                    ))}
                    {comp.pins.length > 6 && (
                      <span className="text-[10px] font-mono text-[#666] self-center">
                        +{comp.pins.length - 6} more
                      </span>
                    )}
                  </div>
                </div>
              )}

              <div className="pt-2 border-t border-[#222] flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  {comp.datasheetUrl && (
                    <a
                      href={comp.datasheetUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="text-[11px] text-[#00FF00] hover:underline flex items-center space-x-1 font-mono"
                    >
                      <span>PDF</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}

                  <a
                    href={lcscUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="text-[11px] text-[#F27D26] hover:underline flex items-center space-x-1 font-mono"
                    title="Search part on LCSC"
                  >
                    <span>LCSC Part</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>

                <button
                  onClick={() => handleAddComponentToProject(comp)}
                  className="px-3 py-1.5 bg-[#00FF00] hover:bg-[#00DD00] text-[#0A0A0B] font-bold rounded-sm text-xs font-mono uppercase flex items-center space-x-1 transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Part</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Custom Component Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-[#0A0A0B]/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#111112] border border-[#333] rounded-sm p-5 max-w-lg w-full space-y-4 shadow-2xl">
            <h3 className="text-sm font-mono font-bold text-white uppercase tracking-wider border-b border-[#222] pb-2">
              Add Component to Database
            </h3>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-mono text-[#888] mb-1 uppercase">Component Name</label>
                <input
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="w-full bg-[#1A1A1B] border border-[#333] rounded-sm px-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#00FF00]"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-[#888] mb-1 uppercase">Reference Prefix</label>
                <input
                  type="text"
                  value={newRef}
                  onChange={(e) => setNewRef(e.target.value)}
                  className="w-full bg-[#1A1A1B] border border-[#333] rounded-sm px-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#00FF00]"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-[#888] mb-1 uppercase">Manufacturer</label>
                <input
                  type="text"
                  value={newMfg}
                  onChange={(e) => setNewMfg(e.target.value)}
                  className="w-full bg-[#1A1A1B] border border-[#333] rounded-sm px-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#00FF00]"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-[#888] mb-1 uppercase">Part Number (MPN)</label>
                <input
                  type="text"
                  value={newMpn}
                  onChange={(e) => setNewMpn(e.target.value)}
                  className="w-full bg-[#1A1A1B] border border-[#333] rounded-sm px-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#00FF00]"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-[#F27D26] mb-1 uppercase">LCSC Part Number (e.g. C52382)</label>
                <input
                  type="text"
                  value={newLcsc}
                  onChange={(e) => setNewLcsc(e.target.value)}
                  placeholder="e.g. C2913202"
                  className="w-full bg-[#1A1A1B] border border-[#F27D26]/50 rounded-sm px-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#F27D26]"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-[#888] mb-1 uppercase">Package / Footprint</label>
                <input
                  type="text"
                  value={newPackage}
                  onChange={(e) => setNewPackage(e.target.value)}
                  className="w-full bg-[#1A1A1B] border border-[#333] rounded-sm px-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#00FF00]"
                />
              </div>

              <div className="col-span-2">
                <label className="block text-xs font-mono text-[#888] mb-1 uppercase">Value / Specs</label>
                <input
                  type="text"
                  value={newValue}
                  onChange={(e) => setNewValue(e.target.value)}
                  className="w-full bg-[#1A1A1B] border border-[#333] rounded-sm px-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#00FF00]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-mono text-[#888] mb-1 uppercase">Description</label>
              <textarea
                value={newDesc}
                onChange={(e) => setNewDesc(e.target.value)}
                rows={2}
                className="w-full bg-[#1A1A1B] border border-[#333] rounded-sm p-2 text-xs text-white focus:outline-none focus:border-[#00FF00]"
              />
            </div>

            <div className="flex items-center justify-end space-x-2 pt-2 border-t border-[#222]">
              <button
                onClick={() => setShowAddModal(false)}
                className="px-3 py-1.5 bg-[#222] text-[#AAA] rounded-sm text-xs font-mono uppercase border border-[#444]"
              >
                Cancel
              </button>
              <button
                onClick={handleCreateCustomComponent}
                className="px-4 py-1.5 bg-[#00FF00] hover:bg-[#00DD00] text-[#0A0A0B] font-bold rounded-sm text-xs font-mono uppercase"
              >
                Save Component
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
