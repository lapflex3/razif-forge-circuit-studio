'use client';

import React, { useState } from 'react';
import { Layers, Download, CircuitBoard, Check, Shield, FileCode2, ExternalLink } from 'lucide-react';
import { ProjectData } from '@/lib/types/eda';
import { exportToKiCad } from '@/lib/eda/kicadExporter';

interface PCBViewProps {
  project: ProjectData;
}

export function PCBView({ project }: PCBViewProps) {
  const [boardWidth, setBoardWidth] = useState(65);
  const [boardHeight, setBoardHeight] = useState(45);
  const [copperLayers, setCopperLayers] = useState(2);
  const [traceMinMil, setTraceMinMil] = useState(6);

  const handleExportKiCad = () => {
    const result = exportToKiCad(project);
    const blob = new Blob([result.schematicContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${result.projectName}.kicad_sch`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-xl">
        <div className="space-y-1">
          <div className="flex items-center space-x-2 text-xs font-mono font-semibold text-emerald-400 uppercase">
            <Layers className="w-4 h-4" />
            <span>PCB Layout & KiCad Integration Roadmap</span>
          </div>
          <h1 className="text-xl font-bold text-slate-100">PCB Board Design & KiCad Sync</h1>
          <p className="text-xs text-slate-400">
            Preview board dimensions, FR-4 copper stackup rules, component placement boundaries, and export to KiCad.
          </p>
        </div>

        <button
          onClick={handleExportKiCad}
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold rounded-lg text-xs flex items-center space-x-1.5 transition-colors shadow-lg"
        >
          <FileCode2 className="w-4 h-4" />
          <span>Export KiCad Schematic (.kicad_sch)</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* PCB Board Outline Preview Canvas */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-bold text-slate-100">2D PCB Board Outline (FR-4 Substrate)</span>
            <span className="text-xs font-mono text-emerald-400">{boardWidth} mm × {boardHeight} mm</span>
          </div>

          {/* Visual Board Box */}
          <div className="h-72 bg-emerald-950/80 border-4 border-emerald-600 rounded-lg p-4 relative overflow-hidden flex items-center justify-center shadow-inner">
            <div className="absolute inset-0 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:16px_16px] opacity-20" />

            {/* Watermark Overlay inside PCB preview */}
            <div className="watermark-overlay">
              <span>RazifSoftwares</span>
              <span className="text-[#888]">|</span>
              <span>PCB Silk-Screen Engine</span>
            </div>

            {/* Corner Mounting Holes */}
            <div className="absolute top-3 left-3 w-4 h-4 rounded-full border-2 border-amber-400 bg-slate-950" />
            <div className="absolute top-3 right-3 w-4 h-4 rounded-full border-2 border-amber-400 bg-slate-950" />
            <div className="absolute bottom-3 left-3 w-4 h-4 rounded-full border-2 border-amber-400 bg-slate-950" />
            <div className="absolute bottom-3 right-3 w-4 h-4 rounded-full border-2 border-amber-400 bg-slate-950" />

            {/* Component Footprints Preview */}
            <div className="grid grid-cols-3 gap-4 z-10">
              {project.components.slice(0, 6).map((comp, idx) => (
                <div
                  key={idx}
                  className="p-2 bg-emerald-900/90 border border-emerald-400 rounded text-center text-[10px] font-mono text-emerald-200 shadow-md"
                >
                  <div className="font-bold text-amber-300">{comp.ref}</div>
                  <div className="text-[9px] opacity-80">{comp.package}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="text-[11px] font-mono text-slate-400 bg-slate-950 p-2.5 rounded border border-slate-800 flex justify-between">
            <span>Component Count: {project.components.length}</span>
            <span>Net Traces: {project.nets.length}</span>
            <span>Stackup: {copperLayers}-Layer FR-4 (1.6mm)</span>
          </div>
        </div>

        {/* Board Design Rules Parameters */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <h2 className="text-sm font-bold text-slate-100 font-mono uppercase text-emerald-400">
            PCB Constraints
          </h2>

          <div>
            <label className="block text-xs text-slate-400 mb-1">Board Width (mm)</label>
            <input
              type="number"
              value={boardWidth}
              onChange={(e) => setBoardWidth(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-100 font-mono"
            />
          </div>

          <div>
            <label className="block text-xs text-slate-400 mb-1">Board Height (mm)</label>
            <input
              type="number"
              value={boardHeight}
              onChange={(e) => setBoardHeight(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-100 font-mono"
            />
          </div>

          <div>
            <label className="block text-xs text-slate-400 mb-1">Copper Layers</label>
            <select
              value={copperLayers}
              onChange={(e) => setCopperLayers(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-100 font-mono"
            >
              <option value={2}>2-Layer Board (Top / Bottom)</option>
              <option value={4}>4-Layer Board (Top / GND / 3.3V / Bottom)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs text-slate-400 mb-1">Min Trace Width (mil)</label>
            <input
              type="number"
              value={traceMinMil}
              onChange={(e) => setTraceMinMil(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-100 font-mono"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
