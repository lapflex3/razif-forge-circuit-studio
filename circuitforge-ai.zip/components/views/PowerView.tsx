'use client';

import React, { useState } from 'react';
import { Zap, AlertTriangle, Plus, Thermometer, ShieldAlert, Cpu } from 'lucide-react';
import { ProjectData, PowerRail } from '@/lib/types/eda';

interface PowerViewProps {
  project: ProjectData;
  onUpdateProject: (p: ProjectData) => void;
}

export function PowerView({ project, onUpdateProject }: PowerViewProps) {
  const [showAddModal, setShowAddModal] = useState(false);
  const [railName, setRailName] = useState('3V3_AUX_RAIL');
  const [voltage, setVoltage] = useState(3.3);
  const [currentMa, setCurrentMa] = useState(250);
  const [powerSource, setPowerSource] = useState('Secondary Regulator');

  const totalCurrentMa = project.powerRails.reduce((sum, r) => sum + r.estimatedCurrent, 0);
  const totalPowerW = project.powerRails.reduce((sum, r) => sum + (r.voltage * (r.estimatedCurrent / 1000)), 0);

  const handleAddRail = () => {
    if (!railName.trim()) return;
    const newRail: PowerRail = {
      id: 'pr_' + Date.now(),
      name: railName,
      voltage,
      estimatedCurrent: currentMa,
      powerSource,
      efficiency: 90,
      estimatedHeatMw: Math.round((voltage * (currentMa / 1000)) * 100),
    };

    onUpdateProject({ ...project, powerRails: [...project.powerRails, newRail] });
    setShowAddModal(false);
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-xl">
        <div className="space-y-1">
          <div className="flex items-center space-x-2 text-xs font-mono font-semibold text-amber-400 uppercase">
            <Zap className="w-4 h-4" />
            <span>Power Architecture & Thermal Loss Analyzer</span>
          </div>
          <h1 className="text-xl font-bold text-slate-100">Power Tree Analysis</h1>
          <p className="text-xs text-slate-400">
            System voltage distribution rails, estimated load currents, regulator thermal losses, and power budget.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg text-xs flex items-center space-x-1.5 transition-colors shadow-lg"
        >
          <Plus className="w-4 h-4" />
          <span>Add Power Rail</span>
        </button>
      </div>

      {/* Overview Budget Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-1">
          <div className="text-[10px] font-mono text-slate-400 uppercase">Total Peak System Current</div>
          <div className="text-2xl font-bold text-amber-400 font-mono">{totalCurrentMa} mA</div>
          <div className="text-[10px] text-slate-500">Sum of max load draws</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-1">
          <div className="text-[10px] font-mono text-slate-400 uppercase">Total Power Consumption</div>
          <div className="text-2xl font-bold text-emerald-400 font-mono">{totalPowerW.toFixed(2)} W</div>
          <div className="text-[10px] text-slate-500">Calculated power draw</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-1">
          <div className="text-[10px] font-mono text-slate-400 uppercase">System Power Rails</div>
          <div className="text-2xl font-bold text-cyan-400 font-mono">{project.powerRails.length} Rails</div>
          <div className="text-[10px] text-slate-500">Regulated & Pass-through</div>
        </div>
      </div>

      {/* Power Tree Visual Cards */}
      <div className="space-y-4">
        <div className="text-xs font-mono font-semibold uppercase text-slate-400">
          Power Rail Hierarchy Breakdown
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {project.powerRails.map((rail) => {
            const powerMw = Math.round(rail.voltage * rail.estimatedCurrent);
            const isHighHeat = rail.notes?.includes('heat') || rail.estimatedHeatMw! > 400;

            return (
              <div
                key={rail.id}
                className={`bg-slate-900 border rounded-xl p-4 space-y-3 relative overflow-hidden shadow-md ${
                  isHighHeat ? 'border-amber-700/80 bg-amber-950/20' : 'border-slate-800'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-mono uppercase text-amber-400 font-semibold">
                      {rail.powerSource}
                    </span>
                    <h3 className="text-sm font-bold text-slate-100">{rail.name}</h3>
                  </div>

                  <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-amber-950 border border-amber-800 text-amber-300">
                    {rail.voltage}V
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                  <div>
                    <span className="text-slate-500 block text-[10px]">Peak Draw</span>
                    <span className="text-slate-200 font-semibold">{rail.estimatedCurrent} mA</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">Total Power</span>
                    <span className="text-slate-200 font-semibold">{powerMw} mW</span>
                  </div>
                  {rail.efficiency && (
                    <div>
                      <span className="text-slate-500 block text-[10px]">Efficiency</span>
                      <span className="text-emerald-400 font-semibold">{rail.efficiency}%</span>
                    </div>
                  )}
                  {rail.estimatedHeatMw && (
                    <div>
                      <span className="text-slate-500 block text-[10px]">Heat Loss</span>
                      <span className={isHighHeat ? 'text-amber-400 font-bold' : 'text-slate-300'}>
                        {rail.estimatedHeatMw} mW
                      </span>
                    </div>
                  )}
                </div>

                {rail.notes && (
                  <div className="text-[11px] text-amber-300/90 bg-amber-950/60 p-2 rounded border border-amber-800/80 flex items-start space-x-1.5">
                    <Thermometer className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                    <span>{rail.notes}</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Add Power Rail Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 max-w-md w-full space-y-4">
            <h3 className="text-sm font-bold text-slate-100">Add System Power Rail</h3>

            <div>
              <label className="block text-xs text-slate-400 mb-1">Rail Name</label>
              <input
                type="text"
                value={railName}
                onChange={(e) => setRailName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">Voltage (V)</label>
              <input
                type="number"
                step="0.1"
                value={voltage}
                onChange={(e) => setVoltage(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-amber-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">Estimated Load Current (mA)</label>
              <input
                type="number"
                value={currentMa}
                onChange={(e) => setCurrentMa(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-amber-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">Power Source / Origin</label>
              <input
                type="text"
                value={powerSource}
                onChange={(e) => setPowerSource(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="flex items-center justify-end space-x-2 pt-2 border-t border-slate-800">
              <button
                onClick={() => setShowAddModal(false)}
                className="px-3 py-1.5 bg-slate-800 text-slate-300 rounded text-xs"
              >
                Cancel
              </button>
              <button
                onClick={handleAddRail}
                className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded text-xs"
              >
                Add Rail
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
