'use client';

import React, { useState, useRef, useEffect } from 'react';
import { 
  Boxes, 
  Plus, 
  Trash2, 
  ZoomIn, 
  ZoomOut, 
  RotateCcw, 
  Sparkles, 
  Zap, 
  Link2,
  Edit2,
  Check,
  X,
  Loader2,
  Maximize2
} from 'lucide-react';
import { ProjectData, BlockNode, BlockConnection } from '@/lib/types/eda';

const getRandomId = (prefix: string) => `${prefix}_${Math.random().toString(36).substring(2, 9)}`;

interface BlocksViewProps {
  project: ProjectData;
  onUpdateProject: (p: ProjectData) => void;
}

export function BlocksView({ project, onUpdateProject }: BlocksViewProps) {
  const [selectedBlockId, setSelectedBlockId] = useState<string | null>(null);
  const [connectingSourceId, setConnectingSourceId] = useState<string | null>(null);
  const [editingBlockId, setEditingBlockId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState('');

  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const [panStart, setPanStart] = useState({ x: 0, y: 0 });

  const [draggingBlockId, setDraggingBlockId] = useState<string | null>(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  
  const [showAddModal, setShowAddModal] = useState(false);
  const [isAiConnecting, setIsAiConnecting] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // New Block Form state
  const [newBlockName, setNewBlockName] = useState('Power Regulator');
  const [newBlockType, setNewBlockType] = useState('PMIC');
  const [newBlockRail, setNewBlockRail] = useState('3.3V');
  const [newBlockDesc, setNewBlockDesc] = useState('Low drop-out voltage regulator');

  const containerRef = useRef<HTMLDivElement>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Dragging blocks
  const handleBlockMouseDown = (e: React.MouseEvent, block: BlockNode) => {
    if (e.button !== 0) return; // Only left click
    e.stopPropagation();
    setSelectedBlockId(block.id);
    
    // If in connecting mode, connect source to target
    if (connectingSourceId && connectingSourceId !== block.id) {
      handleCompleteConnection(connectingSourceId, block.id);
      return;
    }

    setDraggingBlockId(block.id);
    setDragOffset({
      x: e.clientX / zoom - block.x,
      y: e.clientY / zoom - block.y,
    });
  };

  const handleCanvasMouseDown = (e: React.MouseEvent) => {
    if (e.target === containerRef.current || (e.target as HTMLElement).tagName === 'svg') {
      setSelectedBlockId(null);
      setConnectingSourceId(null);
      
      // Start panning
      setIsPanning(true);
      setPanStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (draggingBlockId) {
      const newX = Math.round((e.clientX / zoom - dragOffset.x) / 10) * 10;
      const newY = Math.round((e.clientY / zoom - dragOffset.y) / 10) * 10;

      const updatedBlocks = project.blocks.map((b) =>
        b.id === draggingBlockId ? { ...b, x: Math.max(10, newX), y: Math.max(10, newY) } : b
      );

      onUpdateProject({ ...project, blocks: updatedBlocks });
    } else if (isPanning) {
      setPan({
        x: e.clientX - panStart.x,
        y: e.clientY - panStart.y,
      });
    }
  };

  const handleMouseUp = () => {
    setDraggingBlockId(null);
    setIsPanning(false);
  };

  const handleDeleteBlock = (blockId: string) => {
    const updatedBlocks = project.blocks.filter((b) => b.id !== blockId);
    const updatedConns = project.blockConnections.filter(
      (c) => c.sourceBlockId !== blockId && c.targetBlockId !== blockId
    );
    onUpdateProject({ ...project, blocks: updatedBlocks, blockConnections: updatedConns });
    if (selectedBlockId === blockId) setSelectedBlockId(null);
    showToast('Block removed');
  };

  const handleStartEditingName = (block: BlockNode, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingBlockId(block.id);
    setEditingName(block.name);
  };

  const handleSaveBlockName = (blockId: string) => {
    if (editingName.trim()) {
      const updatedBlocks = project.blocks.map((b) =>
        b.id === blockId ? { ...b, name: editingName.trim() } : b
      );
      onUpdateProject({ ...project, blocks: updatedBlocks });
    }
    setEditingBlockId(null);
  };

  const handleStartConnection = (blockId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (connectingSourceId === blockId) {
      setConnectingSourceId(null);
    } else if (connectingSourceId) {
      handleCompleteConnection(connectingSourceId, blockId);
    } else {
      setConnectingSourceId(blockId);
      showToast('Click another block to complete connection');
    }
  };

  const handleCompleteConnection = (srcId: string, tgtId: string) => {
    if (srcId === tgtId) return;
    
    // Check if connection exists
    const exists = project.blockConnections.some(
      (c) => (c.sourceBlockId === srcId && c.targetBlockId === tgtId) ||
             (c.sourceBlockId === tgtId && c.targetBlockId === srcId)
    );

    if (exists) {
      showToast('Connection already exists');
      setConnectingSourceId(null);
      return;
    }

    const srcBlock = project.blocks.find(b => b.id === srcId);
    const tgtBlock = project.blocks.find(b => b.id === tgtId);

    // Infer net name
    let netName = 'BUS_NET';
    if (srcBlock?.voltageRail) netName = srcBlock.voltageRail;
    else if (srcBlock?.type.toLowerCase().includes('micro') || tgtBlock?.type.toLowerCase().includes('micro')) netName = 'I2C_BUS';

    const newConn: BlockConnection = {
      id: getRandomId('conn'),
      sourceBlockId: srcId,
      targetBlockId: tgtId,
      netName,
    };

    onUpdateProject({
      ...project,
      blockConnections: [...project.blockConnections, newConn],
    });

    setConnectingSourceId(null);
    showToast(`Connected ${srcBlock?.name} -> ${tgtBlock?.name}`);
  };

  const handleDeleteConnection = (connId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updatedConns = project.blockConnections.filter((c) => c.id !== connId);
    onUpdateProject({ ...project, blockConnections: updatedConns });
    showToast('Wire connection removed');
  };

  const handleAddBlock = () => {
    if (!newBlockName.trim()) return;
    const newBlock: BlockNode = {
      id: getRandomId('blk'),
      name: newBlockName,
      type: newBlockType,
      x: 200 + (project.blocks.length * 40) % 400,
      y: 150 + (project.blocks.length * 30) % 300,
      width: 190,
      height: 95,
      inputs: [{ id: 'in_1', name: 'In', type: 'input' }],
      outputs: [{ id: 'out_1', name: 'Out', type: 'output' }],
      voltageRail: newBlockRail,
      description: newBlockDesc,
    };

    onUpdateProject({ ...project, blocks: [...project.blocks, newBlock] });
    setShowAddModal(false);
    showToast(`Added block: ${newBlockName}`);
  };

  // Ask AI to connect blocks automatically
  const handleAiAutoConnect = () => {
    setIsAiConnecting(true);
    setTimeout(() => {
      const blocks = project.blocks;
      if (blocks.length < 2) {
        showToast('Add at least 2 blocks to auto-connect');
        setIsAiConnecting(false);
        return;
      }

      // Smart algorithm to connect power -> MCU, MCU -> peripherals/sensors/displays
      const newConns: BlockConnection[] = [...project.blockConnections];
      let addedCount = 0;

      const pwrBlock = blocks.find(b => b.type.toLowerCase().includes('power') || b.type.toLowerCase().includes('battery') || b.type.toLowerCase().includes('regulator'));
      const mcuBlock = blocks.find(b => b.type.toLowerCase().includes('micro') || b.type.toLowerCase().includes('mcu') || b.name.toLowerCase().includes('esp32'));
      const peripherals = blocks.filter(b => b !== pwrBlock && b !== mcuBlock);

      // Connect Power to MCU
      if (pwrBlock && mcuBlock) {
        const hasConn = newConns.some(c => (c.sourceBlockId === pwrBlock.id && c.targetBlockId === mcuBlock.id));
        if (!hasConn) {
          newConns.push({
            id: getRandomId('conn_ai_pwr'),
            sourceBlockId: pwrBlock.id,
            targetBlockId: mcuBlock.id,
            netName: pwrBlock.voltageRail || '3V3_PWR',
          });
          addedCount++;
        }
      }

      // Connect MCU to all peripherals
      if (mcuBlock) {
        peripherals.forEach((per, idx) => {
          const hasConn = newConns.some(c => (c.sourceBlockId === mcuBlock.id && c.targetBlockId === per.id) || (c.sourceBlockId === per.id && c.targetBlockId === mcuBlock.id));
          if (!hasConn) {
            let net = 'SPI_BUS';
            if (per.name.toLowerCase().includes('sensor') || per.type.toLowerCase().includes('sensor')) net = 'I2C_BUS';
            if (per.name.toLowerCase().includes('display') || per.type.toLowerCase().includes('oled')) net = 'I2C_BUS';
            if (per.name.toLowerCase().includes('wifi') || per.name.toLowerCase().includes('bluetooth') || per.name.toLowerCase().includes('lora')) net = 'UART_TX_RX';

            newConns.push({
              id: getRandomId(`conn_ai_${idx}`),
              sourceBlockId: mcuBlock.id,
              targetBlockId: per.id,
              netName: net,
            });
            addedCount++;
          }
        });
      }

      onUpdateProject({ ...project, blockConnections: newConns });
      setIsAiConnecting(false);
      showToast(`AI connected ${addedCount} logical block nets!`);
    }, 800);
  };

  return (
    <div
      className="flex-1 h-full bg-[#070708] flex flex-col select-none relative overflow-hidden"
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
    >
      {/* Top Toolbar */}
      <div className="h-11 bg-[#111112] border-b border-[#222] px-4 flex items-center justify-between shrink-0 z-20">
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-1.5 text-xs font-mono text-[#00FF00] font-bold uppercase tracking-wider">
            <Boxes className="w-4 h-4" />
            <span>Functional Block Diagram Editor</span>
          </div>

          <div className="h-4 w-[1px] bg-[#333]" />

          <button
            onClick={() => setShowAddModal(true)}
            className="px-3 py-1 bg-[#00FF00] hover:bg-[#00DD00] text-[#0A0A0B] font-bold rounded-sm text-xs font-mono uppercase flex items-center space-x-1 transition-colors shadow-[0_0_8px_rgba(0,255,0,0.15)]"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Block</span>
          </button>

          <button
            onClick={handleAiAutoConnect}
            disabled={isAiConnecting}
            className="px-3 py-1 bg-[#1F1713] hover:bg-[#2A1E17] text-[#F27D26] border border-[#F27D26]/60 font-bold rounded-sm text-xs font-mono uppercase flex items-center space-x-1.5 transition-colors disabled:opacity-50"
            title="Ask AI to analyze components and auto-wire block nets"
          >
            {isAiConnecting ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Sparkles className="w-3.5 h-3.5 text-[#F27D26]" />
            )}
            <span>Ask AI to Connect Blocks</span>
          </button>
        </div>

        {/* Zoom & Reset Controls */}
        <div className="flex items-center space-x-2">
          {connectingSourceId && (
            <span className="text-[10px] font-mono bg-[#00FF00]/10 text-[#00FF00] px-2 py-0.5 border border-[#00FF00]/40 rounded-sm animate-pulse">
              Select target block to connect
            </span>
          )}

          <div className="h-4 w-[1px] bg-[#333]" />

          <button
            onClick={() => setZoom(Math.max(0.4, zoom - 0.1))}
            className="p-1.5 rounded-sm text-[#888] hover:text-white hover:bg-[#222]"
            title="Zoom Out"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <span className="text-xs font-mono text-[#888] font-bold min-w-[40px] text-center">
            {Math.round(zoom * 100)}%
          </span>
          <button
            onClick={() => setZoom(Math.min(2.5, zoom + 0.1))}
            className="p-1.5 rounded-sm text-[#888] hover:text-white hover:bg-[#222]"
            title="Zoom In"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            onClick={() => { setZoom(1.0); setPan({ x: 0, y: 0 }); }}
            className="p-1.5 rounded-sm text-[#888] hover:text-white hover:bg-[#222]"
            title="Reset View"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Canvas Area */}
      <div
        ref={containerRef}
        onMouseDown={handleCanvasMouseDown}
        className="flex-1 relative overflow-hidden cursor-crosshair bg-[radial-gradient(#222225_1px,transparent_1px)] [background-size:24px_24px] bg-[#070708]"
      >
        {/* Transform Container for Pan & Zoom */}
        <div
          className="absolute inset-0 origin-top-left transition-transform duration-75"
          style={{
            transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
          }}
        >
          {/* SVG Wires Layer */}
          <svg className="absolute inset-0 w-[4000px] h-[4000px] pointer-events-none z-0">
            {project.blockConnections.map((conn) => {
              const srcBlock = project.blocks.find((b) => b.id === conn.sourceBlockId);
              const tgtBlock = project.blocks.find((b) => b.id === conn.targetBlockId);
              if (!srcBlock || !tgtBlock) return null;

              const x1 = srcBlock.x + srcBlock.width;
              const y1 = srcBlock.y + srcBlock.height / 2;
              const x2 = tgtBlock.x;
              const y2 = tgtBlock.y + tgtBlock.height / 2;

              const dx = Math.abs(x2 - x1) / 2;
              const pathData = `M ${x1} ${y1} C ${x1 + dx} ${y1}, ${x2 - dx} ${y2}, ${x2} ${y2}`;

              const midX = (x1 + x2) / 2;
              const midY = (y1 + y2) / 2;

              return (
                <g key={conn.id} className="group pointer-events-auto cursor-pointer">
                  <path
                    d={pathData}
                    fill="none"
                    stroke="#00FF00"
                    strokeWidth="2.5"
                    strokeDasharray={conn.netName?.includes('BUS') || conn.netName?.includes('TX') ? '4,4' : 'none'}
                    className="transition-all hover:stroke-white hover:stroke-[3.5px]"
                  />
                  {conn.netName && (
                    <g transform={`translate(${midX}, ${midY})`}>
                      <rect
                        x="-30"
                        y="-10"
                        width="60"
                        height="16"
                        rx="2"
                        fill="#0A0A0B"
                        stroke="#00FF00"
                        strokeWidth="1"
                      />
                      <text
                        x="0"
                        y="2"
                        fill="#00FF00"
                        fontSize="9"
                        fontFamily="monospace"
                        fontWeight="bold"
                        textAnchor="middle"
                      >
                        {conn.netName}
                      </text>
                    </g>
                  )}
                  {/* Delete wire button */}
                  <g
                    onClick={(e) => handleDeleteConnection(conn.id, e)}
                    className="opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                    transform={`translate(${midX + 35}, ${midY - 6})`}
                  >
                    <circle r="8" fill="#111" stroke="#F27D26" strokeWidth="1" />
                    <text x="0" y="3" fill="#F27D26" fontSize="10" fontWeight="bold" textAnchor="middle">×</text>
                  </g>
                </g>
              );
            })}
          </svg>

          {/* Block Nodes Layer */}
          {project.blocks.map((block) => {
            const isSelected = block.id === selectedBlockId;
            const isConnectingSource = block.id === connectingSourceId;
            const isEditing = block.id === editingBlockId;

            return (
              <div
                key={block.id}
                onMouseDown={(e) => handleBlockMouseDown(e, block)}
                style={{
                  left: `${block.x}px`,
                  top: `${block.y}px`,
                  width: `${block.width}px`,
                  height: `${block.height}px`,
                }}
                className={`absolute bg-[#111112] border-2 rounded-sm p-3 shadow-2xl transition-shadow flex flex-col justify-between cursor-grab active:cursor-grabbing z-10 ${
                  isConnectingSource
                    ? 'border-[#00FF00] ring-2 ring-[#00FF00]/50 shadow-[0_0_15px_rgba(0,255,0,0.4)]'
                    : isSelected
                    ? 'border-[#00FF00] shadow-[0_0_12px_rgba(0,255,0,0.2)]'
                    : 'border-[#333] hover:border-[#555]'
                }`}
              >
                {/* Node Title & Edit / Delete Controls */}
                <div className="flex items-start justify-between">
                  <div className="flex-1 mr-2">
                    <div className="text-[9px] font-mono uppercase text-[#00FF00] font-bold tracking-wider">
                      {block.type}
                    </div>

                    {isEditing ? (
                      <div className="flex items-center space-x-1 mt-0.5">
                        <input
                          type="text"
                          value={editingName}
                          onChange={(e) => setEditingName(e.target.value)}
                          onKeyDown={(e) => e.key === 'Enter' && handleSaveBlockName(block.id)}
                          className="bg-[#0A0A0B] border border-[#00FF00] text-xs font-bold text-white px-1 py-0.5 rounded-sm focus:outline-none w-full"
                          autoFocus
                        />
                        <button
                          onClick={() => handleSaveBlockName(block.id)}
                          className="text-[#00FF00] p-0.5 hover:bg-[#222]"
                        >
                          <Check className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <div
                        onDoubleClick={(e) => handleStartEditingName(block, e)}
                        className="text-xs font-bold text-white flex items-center space-x-1 group/title cursor-pointer"
                        title="Double click to rename"
                      >
                        <span className="truncate">{block.name}</span>
                        <Edit2 className="w-3 h-3 text-[#666] opacity-0 group-hover/title:opacity-100 transition-opacity" />
                      </div>
                    )}
                  </div>

                  <div className="flex items-center space-x-1">
                    <button
                      onClick={(e) => handleStartConnection(block.id, e)}
                      className={`p-1 rounded-sm border transition-colors ${
                        isConnectingSource
                          ? 'bg-[#00FF00] text-[#0A0A0B] border-[#00FF00]'
                          : 'bg-[#1A1A1B] text-[#888] border-[#333] hover:text-[#00FF00] hover:border-[#00FF00]'
                      }`}
                      title={isConnectingSource ? 'Cancel Connection' : 'Connect to another block'}
                    >
                      <Link2 className="w-3 h-3" />
                    </button>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteBlock(block.id);
                      }}
                      className="p-1 rounded-sm bg-[#1A1A1B] text-[#666] hover:text-[#F27D26] border border-[#333] hover:border-[#F27D26] transition-colors"
                      title="Delete Block"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>

                {/* Node Description */}
                <div className="text-[10px] text-[#888] line-clamp-2 my-1 font-sans">
                  {block.description}
                </div>

                {/* Footer Rail & Current */}
                <div className="flex items-center justify-between text-[9px] font-mono border-t border-[#222] pt-1 mt-1">
                  {block.voltageRail ? (
                    <span className="px-1.5 py-0.5 rounded-sm bg-[#1F1713] border border-[#F27D26]/60 text-[#F27D26] font-bold">
                      {block.voltageRail}
                    </span>
                  ) : (
                    <span className="text-[#555]">GND</span>
                  )}
                  {block.currentDraw && (
                    <span className="text-[#888] font-bold">{block.currentDraw}</span>
                  )}
                </div>

                {/* Connection Port Handles */}
                <div
                  onClick={(e) => handleStartConnection(block.id, e)}
                  className="absolute -right-2 top-1/2 -translate-y-1/2 w-4 h-4 bg-[#00FF00] border-2 border-[#0A0A0B] rounded-full cursor-pointer hover:scale-125 transition-transform shadow-[0_0_8px_#00FF00]"
                  title="Output Port (Click to wire)"
                />
                <div
                  onClick={(e) => handleStartConnection(block.id, e)}
                  className="absolute -left-2 top-1/2 -translate-y-1/2 w-4 h-4 bg-[#1A1A1B] border-2 border-[#00FF00] rounded-full cursor-pointer hover:scale-125 transition-transform"
                  title="Input Port (Click to connect)"
                />
              </div>
            );
          })}
        </div>

        {/* Watermark Overlay for RazifSoftwares */}
        <div className="watermark-overlay">
          <span>RazifSoftwares</span>
          <span className="text-[#888]">|</span>
          <span>Block Diagram Engine</span>
        </div>
      </div>

      {/* Toast Notification */}
      {toastMessage && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-[#111112] border border-[#00FF00] text-[#00FF00] text-xs font-mono px-4 py-2 rounded-sm shadow-2xl z-50 flex items-center space-x-2 animate-bounce">
          <Zap className="w-3.5 h-3.5" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Add Block Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-[#0A0A0B]/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#111112] border border-[#333] rounded-sm p-5 max-w-md w-full space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#222] pb-2">
              <h3 className="text-sm font-mono font-bold text-white uppercase tracking-wider">
                Add Block Diagram Node
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-[#666] hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div>
              <label className="block text-xs font-mono text-[#888] uppercase mb-1">Block Name</label>
              <input
                type="text"
                value={newBlockName}
                onChange={(e) => setNewBlockName(e.target.value)}
                placeholder="e.g. ESP32-S3 MCU, BME280 Sensor"
                className="w-full bg-[#1A1A1B] border border-[#333] rounded-sm px-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#00FF00]"
              />
            </div>

            <div>
              <label className="block text-xs font-mono text-[#888] uppercase mb-1">Block Category / Type</label>
              <input
                type="text"
                value={newBlockType}
                onChange={(e) => setNewBlockType(e.target.value)}
                placeholder="e.g. Microcontroller, Sensor, Display"
                className="w-full bg-[#1A1A1B] border border-[#333] rounded-sm px-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#00FF00]"
              />
            </div>

            <div>
              <label className="block text-xs font-mono text-[#888] uppercase mb-1">Voltage Rail</label>
              <input
                type="text"
                value={newBlockRail}
                onChange={(e) => setNewBlockRail(e.target.value)}
                placeholder="e.g. 3.3V, 5.0V, VBUS"
                className="w-full bg-[#1A1A1B] border border-[#333] rounded-sm px-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#00FF00]"
              />
            </div>

            <div>
              <label className="block text-xs font-mono text-[#888] uppercase mb-1">Description</label>
              <input
                type="text"
                value={newBlockDesc}
                onChange={(e) => setNewBlockDesc(e.target.value)}
                placeholder="Brief component function description"
                className="w-full bg-[#1A1A1B] border border-[#333] rounded-sm px-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#00FF00]"
              />
            </div>

            <div className="flex items-center justify-end space-x-2 pt-2 border-t border-[#222]">
              <button
                onClick={() => setShowAddModal(false)}
                className="px-3 py-1.5 bg-[#222] text-[#AAA] rounded-sm text-xs font-mono uppercase border border-[#444]"
              >
                Cancel
              </button>
              <button
                onClick={handleAddBlock}
                className="px-3 py-1.5 bg-[#00FF00] hover:bg-[#00DD00] text-[#0A0A0B] font-bold rounded-sm text-xs font-mono uppercase"
              >
                Create Node
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
