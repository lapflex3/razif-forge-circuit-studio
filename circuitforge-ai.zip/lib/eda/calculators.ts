// Engineering Calculators for CircuitForge AI

export function calculateResistorDivider(vin: number, r1: number, r2: number) {
  if (r1 + r2 === 0) return { vout: 0, currentMa: 0, powerMw: 0 };
  const vout = vin * (r2 / (r1 + r2));
  const currentMa = (vin / (r1 + r2)) * 1000;
  const powerMw = (vin * (currentMa / 1000)) * 1000;
  return {
    vout: Number(vout.toFixed(3)),
    currentMa: Number(currentMa.toFixed(3)),
    powerMw: Number(powerMw.toFixed(3))
  };
}

export function calculateLedResistor(vsupply: number, vforward: number, currentMa: number) {
  if (currentMa <= 0 || vsupply <= vforward) {
    return { resistorOhms: 0, powerMw: 0, standardE24: 0 };
  }
  const i = currentMa / 1000;
  const vResistor = vsupply - vforward;
  const resistorOhms = vResistor / i;
  const powerMw = (vResistor * i) * 1000;

  // Find nearest E24 standard resistor value
  const e24Values = [10, 12, 15, 18, 22, 27, 33, 39, 47, 56, 68, 82];
  let multiplier = 1;
  let rTemp = resistorOhms;
  while (rTemp >= 100) {
    rTemp /= 10;
    multiplier *= 10;
  }
  let closest = e24Values[0];
  let minDiff = Math.abs(rTemp - closest);
  e24Values.forEach(val => {
    const diff = Math.abs(rTemp - val);
    if (diff < minDiff) {
      minDiff = diff;
      closest = val;
    }
  });
  const standardE24 = closest * multiplier;

  return {
    resistorOhms: Number(resistorOhms.toFixed(1)),
    powerMw: Number(powerMw.toFixed(1)),
    standardE24
  };
}

export function calculateOhmsLaw(voltage?: number, currentMa?: number, resistance?: number, powerMw?: number) {
  let v = voltage;
  let i = currentMa !== undefined ? currentMa / 1000 : undefined;
  let r = resistance;
  let p = powerMw !== undefined ? powerMw / 1000 : undefined;

  if (v !== undefined && i !== undefined) {
    r = v / i;
    p = v * i;
  } else if (v !== undefined && r !== undefined && r > 0) {
    i = v / r;
    p = (v * v) / r;
  } else if (i !== undefined && r !== undefined) {
    v = i * r;
    p = i * i * r;
  } else if (p !== undefined && v !== undefined && v > 0) {
    i = p / v;
    r = (v * v) / p;
  }

  return {
    voltage: v !== undefined ? Number(v.toFixed(3)) : 0,
    currentMa: i !== undefined ? Number((i * 1000).toFixed(3)) : 0,
    resistance: r !== undefined ? Number(r.toFixed(3)) : 0,
    powerMw: p !== undefined ? Number((p * 1000).toFixed(3)) : 0
  };
}

export function calculateRcFilter(resistanceOhms: number, capacitanceUf: number) {
  const cFarads = capacitanceUf * 1e-6;
  const tauMs = resistanceOhms * cFarads * 1000;
  const fcHz = resistanceOhms > 0 && cFarads > 0 ? 1 / (2 * Math.PI * resistanceOhms * cFarads) : 0;
  return {
    tauMs: Number(tauMs.toFixed(3)),
    fcHz: Number(fcHz.toFixed(1))
  };
}

export function calculateBatteryRuntime(volts: number, capacityAh: number, loadPowerW: number) {
  if (loadPowerW <= 0) return { wattHours: 0, hours: 0, days: 0 };
  const wattHours = volts * capacityAh;
  const hours = wattHours / loadPowerW;
  const days = hours / 24;
  return {
    wattHours: Number(wattHours.toFixed(2)),
    hours: Number(hours.toFixed(1)),
    days: Number(days.toFixed(2))
  };
}

export function calculateRegulatorLoss(vin: number, vout: number, currentMa: number, thetaJA: number = 50, ambientTemp: number = 25) {
  if (vin < vout || currentMa <= 0) {
    return { powerLossW: 0, tempRiseC: 0, junctionTempC: ambientTemp };
  }
  const i = currentMa / 1000;
  const powerLossW = (vin - vout) * i;
  const tempRiseC = powerLossW * thetaJA;
  const junctionTempC = ambientTemp + tempRiseC;
  return {
    powerLossW: Number(powerLossW.toFixed(3)),
    tempRiseC: Number(tempRiseC.toFixed(1)),
    junctionTempC: Number(junctionTempC.toFixed(1))
  };
}

export function calculateLdoThermal(vin: number, vout: number, currentMa: number) {
  const i = currentMa / 1000;
  const powerLossMw = (vin - vout) * i * 1000;
  const estimatedTempRiseC = (powerLossMw / 1000) * 65; // SOT-223 ~65C/W
  const isHot = powerLossMw > 500;
  const recommendation = isHot
    ? 'High thermal dissipation! Recommend switching buck regulator or adding PCB thermal vias.'
    : 'Acceptable thermal dissipation for SOT-223 / SOT-89 package.';

  return {
    powerLossMw,
    estimatedTempRiseC,
    isHot,
    recommendation,
  };
}

