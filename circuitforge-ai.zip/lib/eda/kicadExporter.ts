// KiCad Project & Schematic Exporter Module
import { ProjectData } from '../types/eda';

export interface KiCadExportResult {
  projectName: string;
  schematicContent: string;
  projectFileContent: string;
  netlistContent: string;
  bomCsvContent: string;
}

export function exportToKiCad(project: ProjectData): KiCadExportResult {
  const sanitize = (str: string) => str.replace(/["\n\r]/g, ' ');

  // 1. Generate KiCad 8.0 Schematic file (.kicad_sch)
  let sch = `(kicad_sch (version 20231120) (generator circuitforge_ai)\n`;
  sch += `  (uuid "${project.id}-uuid-sch")\n`;
  sch += `  (paper "A4")\n`;
  sch += `  (title_block\n`;
  sch += `    (title "${sanitize(project.name)}")\n`;
  sch += `    (date "${new Date().toISOString().split('T')[0]}")\n`;
  sch += `    (rev "1.0")\n`;
  sch += `    (company "CircuitForge AI")\n`;
  sch += `    (comment 1 "${sanitize(project.description)}")\n`;
  sch += `  )\n\n`;

  // Components placement in schematic
  sch += `  ;; Schematic Symbols & Components\n`;
  project.components.forEach((comp, idx) => {
    const x = comp.x || (100 + (idx % 4) * 50);
    const y = comp.y || (100 + Math.floor(idx / 4) * 40);
    sch += `  (symbol (lib_id "${sanitize(comp.category)}:${sanitize(comp.name)}")\n`;
    sch += `    (at ${x} ${y} 0)\n`;
    sch += `    (unit 1)\n`;
    sch += `    (in_bom yes) (on_board yes)\n`;
    sch += `    (uuid "comp-${comp.id}")\n`;
    sch += `    (property "Reference" "${sanitize(comp.ref)}" (at ${x} ${y - 10} 0))\n`;
    sch += `    (property "Value" "${sanitize(comp.value || comp.name)}" (at ${x} ${y + 10} 0))\n`;
    sch += `    (property "Footprint" "${sanitize(comp.package)}" (at ${x} ${y + 20} 0))\n`;
    sch += `    (property "Manufacturer" "${sanitize(comp.manufacturer)}" (at ${x} ${y + 30} 0))\n`;
    sch += `    (property "MPN" "${sanitize(comp.partNumber)}" (at ${x} ${y + 40} 0))\n`;
    
    // Pins
    if (comp.pins) {
      comp.pins.forEach((p) => {
        sch += `    (pin "${p.type}" (at ${x} ${y} 0) (name "${p.name}") (number "${p.number}"))\n`;
      });
    }
    sch += `  )\n\n`;
  });

  // Nets & Wires
  sch += `  ;; Nets & Connections\n`;
  project.nets.forEach((net, idx) => {
    sch += `  ;; Net: ${sanitize(net.name)}\n`;
    net.pins.forEach((p, pIdx) => {
      sch += `  (wire (pts (xy ${100 + idx * 20} ${100 + pIdx * 15}) (xy ${150 + idx * 20} ${100 + pIdx * 15})) (stroke (width 0)))\n`;
      sch += `  (label "${sanitize(net.name)}" (at ${150 + idx * 20} ${100 + pIdx * 15} 0) (fields_autoplaced))\n`;
    });
  });

  sch += `)\n`;

  // 2. Generate KiCad Project file (.kicad_pro)
  const pro = JSON.stringify({
    meta: {
      filename: `${project.name.toLowerCase().replace(/[^a-z0-9]/g, '_')}.kicad_pro`,
      version: 1
    },
    net_settings: {
      classes: [
        { name: "Default", clearance: 0.2, trace_width: 0.25, via_dia: 0.8, via_drill: 0.4 },
        { name: "Power", clearance: 0.3, trace_width: 0.6, via_dia: 1.0, via_drill: 0.6 }
      ]
    },
    pcbnew: {
      page_layout: "A4",
      grid: { size_x: 1.27, size_y: 1.27 }
    },
    schematic: {
      annotate_start_num: 1,
      page_layout: "A4"
    }
  }, null, 2);

  // 3. Generate Netlist file (.net)
  let netlist = `(export (version D)\n`;
  netlist += `  (design\n`;
  netlist += `    (source "${project.name}.kicad_sch")\n`;
  netlist += `    (date "${new Date().toISOString()}")\n`;
  netlist += `    (tool "CircuitForge AI KiCad Adapter 1.0")\n`;
  netlist += `  )\n`;
  netlist += `  (components\n`;
  project.components.forEach(comp => {
    netlist += `    (comp (ref "${comp.ref}")\n`;
    netlist += `      (value "${comp.value || comp.name}")\n`;
    netlist += `      (footprint "${comp.package}")\n`;
    netlist += `      (fields\n`;
    netlist += `        (field (name "Manufacturer") "${comp.manufacturer}")\n`;
    netlist += `        (field (name "PartNumber") "${comp.partNumber}")\n`;
    netlist += `      )\n`;
    netlist += `    )\n`;
  });
  netlist += `  )\n`;
  netlist += `  (nets\n`;
  project.nets.forEach((net, idx) => {
    netlist += `    (net (code "${idx + 1}") (name "${net.name}")\n`;
    net.pins.forEach(p => {
      const comp = project.components.find(c => c.id === p.componentId);
      netlist += `      (node (ref "${comp?.ref || 'U?'}") (pin "${p.pinNumber}"))\n`;
    });
    netlist += `    )\n`;
  });
  netlist += `  )\n`;
  netlist += `)\n`;

  // 4. Generate BOM CSV
  let bomCsv = `Reference,Component Name,Value,Manufacturer,Part Number,Package,Quantity,Description,Datasheet\n`;
  project.components.forEach(comp => {
    bomCsv += `"${comp.ref}","${comp.name}","${comp.value || ''}","${comp.manufacturer}","${comp.partNumber}","${comp.package}",1,"${comp.description.replace(/"/g, '""')}","${comp.datasheetUrl || ''}"\n`;
  });

  return {
    projectName: project.name.toLowerCase().replace(/[^a-z0-9]/g, '_'),
    schematicContent: sch,
    projectFileContent: pro,
    netlistContent: netlist,
    bomCsvContent: bomCsv,
  };
}
