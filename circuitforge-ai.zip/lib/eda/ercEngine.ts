// Deterministic Electrical Rules Check (ERC) Engine for CircuitForge AI
import { ProjectData, ERCWarning } from '../types/eda';

export function runERC(project: ProjectData): ERCWarning[] {
  const warnings: ERCWarning[] = [];

  // 1. Check for Power Source & Ground Net
  const hasPowerNet = project.nets.some(n => n.type === 'power' || n.name.toLowerCase().includes('vbus') || n.name.toLowerCase().includes('3v3') || n.name.toLowerCase().includes('5v'));
  const hasGndNet = project.nets.some(n => n.type === 'ground' || n.name.toLowerCase().includes('gnd'));

  if (!hasGndNet) {
    warnings.push({
      id: 'erc_no_gnd',
      severity: 'CRITICAL',
      category: 'GENERAL',
      title: 'Missing Common Ground Net (GND)',
      message: 'No ground reference net (GND) was detected in the project connections.',
      recommendation: 'Add a common GND net connecting ground pins of MCU, regulators, connectors, and ICs.'
    });
  }

  if (!hasPowerNet && project.powerRails.length === 0) {
    warnings.push({
      id: 'erc_no_power',
      severity: 'CRITICAL',
      category: 'POWER',
      title: 'Missing Power Rail Source',
      message: 'No active power rail or power net detected.',
      recommendation: 'Add a power input source (e.g. USB-C 5V VBUS or Li-Ion Battery) and connect to regulators or MCU.'
    });
  }

  // 2. Check MCU decoupling capacitors
  const mcuComponents = project.components.filter(c => c.category === 'MCU' || c.name.toLowerCase().includes('esp32') || c.name.toLowerCase().includes('stm32') || c.name.toLowerCase().includes('rp2040'));
  const capacitorCount = project.components.filter(c => c.category === 'capacitor').length;

  if (mcuComponents.length > 0 && capacitorCount < mcuComponents.length) {
    warnings.push({
      id: 'erc_mcu_decoupling',
      severity: 'WARNING',
      category: 'DECOUPLING',
      title: 'Insufficient Decoupling Capacitors for MCU',
      message: `Detected ${mcuComponents.length} MCU core(s) but only ${capacitorCount} decoupling capacitor(s).`,
      recommendation: 'Place a 100nF ceramic decoupling capacitor directly adjacent to each VCC/VDD power pin of the MCU.'
    });
  }

  // 3. Check I2C Pull-up Resistors
  const i2cNets = project.nets.filter(n => n.name.toLowerCase().includes('sda') || n.name.toLowerCase().includes('scl') || n.name.toLowerCase().includes('i2c'));
  const pullupResistors = project.components.filter(c => c.category === 'resistor' && (c.value?.includes('4.7k') || c.value?.includes('2.2k') || c.value?.includes('10k')));

  if (i2cNets.length > 0 && pullupResistors.length === 0) {
    warnings.push({
      id: 'erc_i2c_pullup',
      severity: 'WARNING',
      category: 'I2C',
      title: 'Missing I2C Bus Pull-Up Resistors',
      message: `I2C communication nets (${i2cNets.map(n => n.name).join(', ')}) require open-drain pull-up resistors to VCC.`,
      recommendation: 'Add 4.7kΩ pull-up resistors from SDA and SCL nets to 3.3V rail.'
    });
  }

  // 4. Check Power Rail Dissipation & Thermal
  project.powerRails.forEach(rail => {
    if (rail.notes?.toLowerCase().includes('heat') || (rail.voltage === 3.3 && rail.estimatedCurrent > 300 && rail.powerSource.toLowerCase().includes('ams1117'))) {
      const heatW = ((5.0 - 3.3) * (rail.estimatedCurrent / 1000)).toFixed(2);
      warnings.push({
        id: `erc_heat_${rail.id}`,
        severity: 'WARNING',
        category: 'POWER',
        title: `LDO Thermal Dissipation Hazard on ${rail.name}`,
        message: `Linear regulator power loss estimated at ~${heatW}W when running at ${rail.estimatedCurrent}mA draw from 5V source.`,
        recommendation: 'Add a PCB copper heat pour area under SOT-223 tab, or switch to a high-efficiency synchronous DC-DC buck converter.'
      });
    }
  });

  // 5. Check Unconnected Component Pins
  const unconnectedComponents: string[] = [];
  project.components.forEach(comp => {
    if (comp.pins && comp.pins.length > 0) {
      const connectedPins = comp.pins.filter(p => p.connectedNetId || project.nets.some(net => net.pins.some(np => np.componentId === comp.id && np.pinNumber === p.number)));
      if (connectedPins.length === 0) {
        unconnectedComponents.push(comp.ref + ' (' + comp.name + ')');
      }
    }
  });

  if (unconnectedComponents.length > 0) {
    warnings.push({
      id: 'erc_unconnected_comps',
      severity: 'WARNING',
      category: 'CONNECTORS',
      title: 'Unconnected Components Found',
      message: `The following components have no pin wire connections: ${unconnectedComponents.join(', ')}.`,
      recommendation: 'Wire component pins into nets or remove unused components from schematic.'
    });
  }

  // 6. Check USB-C CC resistors
  const usbcComps = project.components.filter(c => c.name.toLowerCase().includes('usb-c') || c.package.toLowerCase().includes('usb-c'));
  if (usbcComps.length > 0) {
    const hasCCResistors = project.components.some(c => c.category === 'resistor' && (c.value === '5.1k' || c.value === '5.1kΩ'));
    if (!hasCCResistors) {
      warnings.push({
        id: 'erc_usbc_cc',
        severity: 'WARNING',
        category: 'CONNECTORS',
        title: 'USB-C Type-C CC1/CC2 Pull-Down Resistors Required',
        message: 'USB-C power sink requires two 5.1kΩ resistors on CC1 and CC2 lines to ground for host 5V negotiation.',
        recommendation: 'Connect 5.1kΩ resistor from CC1 to GND, and 5.1kΩ resistor from CC2 to GND.'
      });
    }
  }

  // 7. Pass check if no critical errors
  if (warnings.length === 0) {
    warnings.push({
      id: 'erc_pass_all',
      severity: 'PASS',
      category: 'GENERAL',
      title: 'Basic Electrical Rules Check Passed',
      message: 'All deterministic checks passed cleanly: GND reference present, power rails mapped, MCU decoupling initialized.',
      recommendation: 'Proceed to AI Deep Design Review or KiCad schematic export.'
    });
  }

  return warnings;
}
