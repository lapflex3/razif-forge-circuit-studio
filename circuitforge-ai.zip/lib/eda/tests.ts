// Automated Unit Tests for CircuitForge AI Math & ERC Logic
import { calculateResistorDivider, calculateLedResistor, calculateOhmsLaw, calculateRcFilter, calculateBatteryRuntime } from './calculators';
import { runERC } from './ercEngine';
import { DEMO_PROJECT_ESP32_LORA } from '../sampleData';

export function runSuiteTests() {
  const results: { name: string; passed: boolean; details: string }[] = [];

  // 1. Resistor Divider Test
  const div = calculateResistorDivider(5.0, 10000, 10000);
  const divPass = Math.abs(div.vout - 2.5) < 0.01;
  results.push({
    name: 'Resistor Divider (5V, 10k, 10k)',
    passed: divPass,
    details: `Expected 2.5V, got ${div.vout}V`
  });

  // 2. LED Resistor Test
  const led = calculateLedResistor(5.0, 2.0, 20); // (5 - 2) / 0.02 = 150 ohms
  const ledPass = Math.abs(led.resistorOhms - 150) < 0.1;
  results.push({
    name: 'LED Current Limiting Resistor (5V in, 2V led, 20mA)',
    passed: ledPass,
    details: `Expected 150Ω, got ${led.resistorOhms}Ω`
  });

  // 3. Ohm's Law Test
  const ohm = calculateOhmsLaw(3.3, 100); // 3.3V, 100mA => R = 33 ohms, P = 330mW
  const ohmPass = Math.abs(ohm.resistance - 33) < 0.1 && Math.abs(ohm.powerMw - 330) < 1;
  results.push({
    name: 'Ohm\'s Law Calculation (3.3V, 100mA)',
    passed: ohmPass,
    details: `R: ${ohm.resistance}Ω, P: ${ohm.powerMw}mW`
  });

  // 4. RC Filter Test
  const rc = calculateRcFilter(10000, 0.1); // 10k, 0.1uF => Fc ~ 159.2Hz
  const rcPass = Math.abs(rc.fcHz - 159.2) < 5;
  results.push({
    name: 'RC Filter Cutoff Frequency (10k, 100nF)',
    passed: rcPass,
    details: `Fc: ${rc.fcHz}Hz`
  });

  // 5. Battery Runtime Test
  const bat = calculateBatteryRuntime(3.7, 2.5, 1.85); // 3.7V * 2.5Ah = 9.25Wh / 1.85W = 5 hours
  const batPass = Math.abs(bat.hours - 5.0) < 0.1;
  results.push({
    name: 'Battery Runtime Calculation',
    passed: batPass,
    details: `Expected 5.0h, got ${bat.hours}h`
  });

  // 6. ERC Engine Test
  const warnings = runERC(DEMO_PROJECT_ESP32_LORA);
  const ercPass = warnings.length > 0;
  results.push({
    name: 'Electrical Rules Check (ERC) Engine',
    passed: ercPass,
    details: `Evaluated ${warnings.length} checks/findings on Demo Project.`
  });

  console.log('CircuitForge AI Test Suite Results:', results);
  return results;
}
