// CircuitForge AI - EDA & Project Types

export type Language = 'en' | 'bm';

export type AIProviderType = 'gemini' | 'openai' | 'deepseek' | 'local';

export interface ProjectSkill {
  id: string;
  name: string;
  category: 'power' | 'mcu' | 'rf' | 'erc' | 'thermal' | 'lcsc' | 'pcb' | 'custom';
  description: string;
  promptRules: string;
  author?: string;
  version?: string;
  isSystem?: boolean;
  enabled: boolean;
}

export interface Pin {
  id: string;
  number: string;
  name: string;
  type: 'power_in' | 'power_out' | 'ground' | 'input' | 'output' | 'bidirectional' | 'passive';
  description?: string;
  connectedNetId?: string;
}

export interface ComponentItem {
  id: string;
  ref: string; // e.g., U1, R1, C1, D1, J1
  name: string;
  manufacturer: string;
  partNumber: string;
  category: 
    | 'MCU' 
    | 'regulator' 
    | 'capacitor' 
    | 'resistor' 
    | 'diode' 
    | 'MOSFET' 
    | 'transistor' 
    | 'connector' 
    | 'sensor' 
    | 'display' 
    | 'battery' 
    | 'charger' 
    | 'protection' 
    | 'communication' 
    | 'memory' 
    | 'oscillator' 
    | 'crystal' 
    | 'LED';
  package: string; // e.g., QFN-56, 0805, SOT-23, USB-C-16P
  voltage?: string; // e.g. 3.3V, 5V, 24V
  current?: string; // e.g. 500mA, 2A
  value?: string; // e.g., 10k, 100nF, ESP32-S3-WROOM-1
  description: string;
  datasheetUrl?: string;
  lcscPartNumber?: string;
  symbolId: string;
  footprintId?: string;
  pins: Pin[];
  x?: number;
  y?: number;
  rotation?: number;
}

export interface BlockPort {
  id: string;
  name: string;
  type: 'input' | 'output' | 'power' | 'ground' | 'bus';
}

export interface BlockNode {
  id: string;
  name: string;
  type: string; // e.g., MCU, Power, Protection, Sensor, Display, Interface
  x: number;
  y: number;
  width: number;
  height: number;
  inputs: BlockPort[];
  outputs: BlockPort[];
  voltageRail?: string;
  currentDraw?: string;
  description?: string;
}

export interface BlockConnection {
  id: string;
  sourceBlockId: string;
  sourcePortId?: string;
  targetBlockId: string;
  targetPortId?: string;
  label?: string;
  netName?: string;
}

export interface Net {
  id: string;
  name: string;
  type: 'power' | 'ground' | 'signal' | 'bus';
  voltage?: string;
  pins: {
    componentId: string;
    pinNumber: string;
    pinName: string;
  }[];
}

export interface PowerRail {
  id: string;
  name: string; // e.g., VBUS 5V, 3V3 Rail, VBAT
  voltage: number; // in Volts
  estimatedCurrent: number; // in mA
  powerSource: string;
  efficiency?: number; // % (for regulators)
  estimatedHeatMw?: number;
  notes?: string;
}

export interface ERCWarning {
  id: string;
  code?: string;
  severity: 'CRITICAL' | 'WARNING' | 'INFO' | 'PASS';
  category: 'POWER' | 'MCU' | 'I2C' | 'SPI' | 'GPIO' | 'DECOUPLING' | 'CONNECTORS' | 'GENERAL';
  title: string;
  message: string;
  location?: string;
  recommendation: string;
  resolved?: boolean;
}

export interface BOMItem {
  reference: string;
  componentName: string;
  value: string;
  manufacturer: string;
  partNumber: string;
  package: string;
  quantity: number;
  description: string;
  datasheetUrl?: string;
  priceNote: string;
}

export interface DocumentItem {
  id: string;
  name: string;
  type: 'pdf' | 'txt' | 'md' | 'image';
  size: string;
  uploadDate: string;
  contentSnippet?: string;
}

export interface AILogEntry {
  id: string;
  timestamp: string;
  action: string;
  details: string;
  type: 'user' | 'ai' | 'system';
}

export interface AIProposalOperation {
  action: 'add_component' | 'add_block' | 'connect_blocks' | 'add_net' | 'add_power_rail' | 'fix_warning' | 'modify_circuit';
  title: string;
  description: string;
  payload: any;
}

export interface ProjectData {
  version: '1.0';
  id: string;
  name: string;
  description: string;
  powerSource: string;
  mainController: string;
  interfaces: string[];
  createdAt: string;
  updatedAt: string;
  status: 'Draft' | 'In Progress' | 'Reviewed' | 'Ready for PCB';
  blocks: BlockNode[];
  blockConnections: BlockConnection[];
  components: ComponentItem[];
  nets: Net[];
  powerRails: PowerRail[];
  warnings: ERCWarning[];
  documents: DocumentItem[];
  aiLog: AILogEntry[];
}

export interface CalculatorResult {
  id: string;
  type: string;
  title: string;
  inputs: Record<string, string | number>;
  outputs: Record<string, string | number>;
  timestamp: string;
}

export interface AISettings {
  provider: AIProviderType;
  model: string;
  temperature: number;
  localEndpoint: string;
  customApiKey?: string;
  lcscApiKey?: string;
  onlineApiKeyPresent?: boolean;
  activeSkillIds?: string[];
}

export interface EDASettings {
  defaultUnits: 'mm' | 'mil';
  gridSize: number;
  snapToGrid?: boolean;
  kicadPath: string;
  spiceEnginePath?: string;
  autosaveIntervalMinutes?: number;
}
