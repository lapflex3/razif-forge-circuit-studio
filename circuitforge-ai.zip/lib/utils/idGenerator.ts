// ID and Random Generator Utilities for CircuitForge AI

export function generateId(prefix: string): string {
  const ts = typeof window !== 'undefined' && window.performance ? Math.floor(performance.now() * 1000) : 100000;
  return `${prefix}_${ts}_${Math.floor(Math.random() * 1000)}`;
}

export function generateCoordinates(baseX: number, baseY: number): { x: number; y: number } {
  return {
    x: baseX + Math.floor(Math.random() * 100),
    y: baseY + Math.floor(Math.random() * 100),
  };
}
