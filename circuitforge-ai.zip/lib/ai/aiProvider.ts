// AI Provider Abstraction Interface & Implementations
import { ProjectData, AIProposalOperation } from '../types/eda';

export interface AIResponse {
  text: string;
  proposal?: AIProposalOperation;
  suggestedActions?: string[];
  status: 'success' | 'error';
  errorMessage?: string;
}

export interface AIProviderOptions {
  localEndpoint?: string;
  model?: string;
  provider?: string;
  customApiKey?: string;
  activeSkillRules?: string[];
}

export interface AIProvider {
  sendMessage(
    prompt: string,
    projectContext: ProjectData,
    options?: AIProviderOptions
  ): Promise<AIResponse>;
}

export class GeminiProvider implements AIProvider {
  async sendMessage(
    prompt: string,
    projectContext: ProjectData,
    options?: AIProviderOptions
  ): Promise<AIResponse> {
    try {
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          customApiKey: options?.customApiKey,
          provider: options?.provider || 'gemini',
          model: options?.model || 'gemini-3.6-flash',
          activeSkillRules: options?.activeSkillRules || [],
          projectContext: {
            name: projectContext.name,
            powerSource: projectContext.powerSource,
            mainController: projectContext.mainController,
            blocks: projectContext.blocks.map(b => ({ name: b.name, type: b.type, rail: b.voltageRail })),
            components: projectContext.components.map(c => ({ ref: c.ref, name: c.name, value: c.value, category: c.category, lcsc: c.lcscPartNumber })),
            powerRails: projectContext.powerRails,
            warnings: projectContext.warnings,
          },
        }),
      });

      if (!response.ok) {
        const errData = await response.json();
        return {
          text: `Online AI Error: ${errData.error || 'Server error'}`,
          status: 'error',
          errorMessage: errData.error,
        };
      }

      const data = await response.json();
      return {
        text: data.text,
        proposal: data.proposal,
        suggestedActions: data.suggestedActions,
        status: 'success',
      };
    } catch (err: any) {
      return {
        text: 'Online AI unavailable. Switch to Offline AI or check API key.',
        status: 'error',
        errorMessage: err.message,
      };
    }
  }
}

export class LocalAIProvider implements AIProvider {
  async sendMessage(
    prompt: string,
    projectContext: ProjectData,
    options?: { localEndpoint?: string; model?: string }
  ): Promise<AIResponse> {
    const endpoint = options?.localEndpoint || 'http://localhost:11434';
    const model = options?.model || 'llama3';

    try {
      const res = await fetch(`${endpoint}/api/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model,
          prompt: `System: You are CircuitForge Engineering AI. Project: ${projectContext.name} (${projectContext.mainController}).\nUser: ${prompt}`,
          stream: false,
        }),
      });

      if (!res.ok) {
        return {
          text: `Local AI endpoint (${endpoint}) returned status ${res.status}.`,
          status: 'error',
          errorMessage: 'Local AI unavailable.',
        };
      }

      const data = await res.json();
      return {
        text: data.response || 'No response from local AI model.',
        status: 'success',
      };
    } catch (err: any) {
      return {
        text: `Local AI endpoint unavailable at ${endpoint}. Ensure Ollama or local LLM server is running.`,
        status: 'error',
        errorMessage: err.message,
      };
    }
  }
}
